import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GnomeDesktop from 'gi://GnomeDesktop?version=4.0';
import Meta from 'gi://Meta';
import Mtk from 'gi://Mtk';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import St from 'gi://St';
import Soup from 'gi://Soup?version=3.0';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as AppDisplay from 'resource:///org/gnome/shell/ui/appDisplay.js';
import * as AppFavorites from 'resource:///org/gnome/shell/ui/appFavorites.js';
import * as DND from 'resource:///org/gnome/shell/ui/dnd.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import { readAppFolders } from './shared/appFolders.js';
import { WidgetRuntime } from './widgets/widgetRuntime.js';
import { withDockVisibility } from './dock/dockVisibility.js';
import { withDockOrder } from './dock/dockOrder.js';
import { withMediaWidgets } from './media/mediaWidgets.js';
import { withDockFolders } from './dock/dockFolders.js';
import { withDockAppearance } from './dock/dockAppearance.js';
import { withPanel } from './panel/panel.js';
import { withDesktopWidgets } from './desktop/desktopWidgets.js';
import { withDockMenus } from './dock/dockMenus.js';
import { withDockActivity } from './dock/dockActivity.js';
import { readWidgetCatalog } from './widgets/widgetCatalog.js';
import { create as createClockWidget } from './widgets/clock/widget.js';
import { create as createCalendarWidget } from './widgets/calendar/widget.js';
import { create as createMediaWidget } from './widgets/media/widget.js';
const ExtensionComponents = [withDockVisibility, withDockOrder, withMediaWidgets, withDockFolders,
    withDockAppearance, withPanel, withDesktopWidgets, withDockMenus, withDockActivity]
    .reduce((base, component) => component(base), Extension);
export default class MacosStyleExtension extends ExtensionComponents {
    enable() {
        this._nativePanelState = {
            visible: Main.panel.visible ?? true,
            reactive: Main.panel.reactive ?? true,
        };
        this._appSystem = Shell.AppSystem.get_default();
        this._favorites = AppFavorites.getAppFavorites();
        this._settings = this.getSettings();
        if (this._settings.get_boolean('dock-magnify') &&
            this._settings.get_user_value?.('dock-hover-animation') === null &&
            (this._settings.is_writable?.('dock-hover-animation') ?? true))
            this._settings.set_int('dock-hover-animation', 1);
        this._screens = [];
        this._desktopWidgets = new Map();
        this._widgetAreaSource = 0;
        this._mediaPlayers = new Map();
        this._mediaViews = new Set();
        this._mediaSourceSignals = [];
        this._desktopWindows = new Map();
        this._dockCoverageWindows = new Map();
        this._runningAppSignals = new Map();
        this._attentionWindows = new Map();
        this._workspaceSignals = [];
        this._notificationSources = new Map();
        this._launcherEntries = new Map();
        this._activeTransfers = new Map();
        this._activityRevision = 0;
        this._trashCount = null;
        this._connections = [];
        this._wallClock = new GnomeDesktop.WallClock();
        this._widgetRuntime = new WidgetRuntime(this, { Gio, GLib, St, Clutter, Pango, GnomeDesktop, DND, PopupMenu, Main, Soup, stage: global.stage,
            pointer: () => global.get_pointer() }, readWidgetCatalog, { clock: createClockWidget, calendar: createCalendarWidget, media: createMediaWidget });
        this._connect(this._wallClock, 'notify::clock', () => {
            this._updateClocks();
            this._updateDesktopWidgets();
            this._updateDockWidgets();
        });
        this._menu = new PanelMenu.Button(0.0, 'Applications');
        this._menu.add_style_class_name('macos-panel-menu');
        this._menuBox = new St.BoxLayout({ style_class: 'macos-panel-menu-box' });
        this._menuIcon = new St.Icon({
            icon_name: 'view-app-grid-symbolic',
            style_class: 'system-status-icon',
        });
        this._menuBox.add_child(this._menuIcon);
        this._activeAppLabel = new St.Label({
            text: 'Finder',
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'macos-active-app',
        });
        this._transferLabel = new St.Label({
            style_class: 'macos-transfer-total',
            y_align: Clutter.ActorAlign.CENTER,
            visible: false,
        });
        this._menu.add_child(this._menuBox);
        this._populatePanelMenu(this._menu);
        this._connect(Main.messageTray, 'source-added', (tray, source) => this._watchNotificationSource(source));
        this._connect(Main.messageTray, 'source-removed', (tray, source) => {
            this._unwatchNotificationSource(source);
            this._updateNotificationCounts();
        });
        for (const source of Main.messageTray.getSources())
            this._watchNotificationSource(source);
        this._startLauncherTracking();
        for (const signal of ['window-demands-attention', 'window-marked-urgent'])
            this._connect(global.display, signal, (display, window) => this._trackAttentionWindow(window));
        for (const actor of global.get_window_actors()) {
            const window = actor.meta_window;
            if (window.demands_attention || window.urgent)
                this._trackAttentionWindow(window);
        }
        this._connect(global.display, 'window-created', (display, window) => {
            this._trackDockCoverageWindow(window);
            this._updateDockCoverage();
        });
        this._connect(this._favorites, 'changed', () => this._rebuildDock());
        this._connect(this._appSystem, 'app-state-changed', (system, app) => this._handleAppStateChanged(app));
        this._connect(global.display, 'notify::focus-window', () => this._updateActiveApp());
        this._connect(global.display, 'in-fullscreen-changed', () => {
            for (const screen of this._screens) {
                if (screen.monitor.inFullscreen)
                    this._hideDock(screen, true);
                else if (!screen.edge)
                    this._revealDock(screen);
            }
            this._updateDockCoverage();
        });
        this._connect(global.stage, 'notify::key-focus', () => {
            for (const screen of this._screens) {
                if (this._dockHasFocus(screen))
                    this._revealDock(screen);
                else
                    this._queueDockHide(screen);
            }
        });
        this._connect(Main.layoutManager, 'monitors-changed', () => this._applySettings());
        this._connect(global.display, 'workareas-changed', () => {
            if (this._widgetAreaSource)
                return;
            this._widgetAreaSource = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._refreshDesktopWidgetMenus();
                this._widgetRuntime?.syncWorkAreas();
                this._widgetAreaSource = 0;
                return GLib.SOURCE_REMOVE;
            });
        });
        this._connect(global.workspace_manager, 'active-workspace-changed', () => {
            this._updateDesktopButtons();
            if (this._settings.get_boolean('dock-current-workspace'))
                this._rebuildDock();
            this._updateDockCoverage();
        });
        this._connect(this._settings, 'changed', (settings, key) => {
            if (['widget-monitors', 'widget-errors', 'widget-manager-request', 'widget-state'].includes(key))
                return;
            if (key === 'widget-catalog-revision')
                this._widgetRuntime.reloadCatalog();
            if (key.startsWith('desktop-widget-'))
                this._syncDesktopWidgets();
            else if (key !== 'window-button-layout-backup')
                this._applySettings();
        });
        this._connectOverviewDash();
        this._setupDesktopWidgetMenu();
        this._applySettings();
        this._updateActiveApp();
    }
    disable() {
        this._destroyDesktopWidgetMenu();
        this._stopMediaTracking();
        this._widgetRuntime?.destroy();
        this._widgetRuntime = null;
        this._stopTrashTracking();
        for (const window of [...this._attentionWindows.keys()])
            this._forgetAttentionWindow(window);
        this._disconnectDockCoverageWindows();
        this._syncRunningAppSignals([]);
        this._syncWorkspaceSignals(null);
        if (this._dockRebuildSource)
            GLib.source_remove(this._dockRebuildSource);
        this._dockRebuildSource = 0;
        for (const id of this._dbusSubscriptions)
            Gio.DBus.session.signal_unsubscribe(id);
        this._dbusSubscriptions = [];
        if (this._unityOwner)
            Gio.bus_unown_name(this._unityOwner);
        this._unityOwner = 0;
        this._launcherEntries.clear();
        this._activeTransfers.clear();
        for (const source of [...this._notificationSources.keys()])
            this._unwatchNotificationSource(source);
        for (const [object, id] of this._connections)
            object.disconnect(id);
        this._connections = [];
        this._overviewDash?.show();
        this._overviewDash = null;
        this._destroyDesktopWidgets();
        this._wallClock.run_dispose();
        this._wallClock = null;
        this._dockWallClock?.run_dispose();
        this._dockWallClock = null;
        this._dockClockSettings = null;
        for (const workspace of [...this._desktopWindows.keys()])
            this._restoreDesktop(workspace, false);
        this._restoreWindowButtons();
        this._windowSettings = null;
        if (this._searchBinding)
            Main.wm.removeKeybinding('spotlight-search');
        this._searchBinding = false;
        this._destroyScreens();
        if (this._widgetAreaSource)
            GLib.source_remove(this._widgetAreaSource);
        this._widgetAreaSource = 0;
        this._menu?.destroy();
        this._menu = null;
        this._restoreNativePanel();
        this._appSystem = null;
        this._favorites = null;
        this._settings = null;
        this._transferLabel = null;
    }
    _connect(object, signal, callback) {
        this._connections.push([object, object.connect(signal, callback)]);
    }
    _connectOverviewDash() {
        const dash = Main.overview.dash;
        if (!dash?.showAppsButton)
            return;
        this._overviewDash = dash;
        dash.hide();
    }
    _applySettings() {
        this._refreshDesktopWidgetMenus();
        const focus = this._captureDockFocus();
        this._widgetRuntime?.publishMonitors();
        this._syncMediaPlayers();
        this._updateWindowButtons();
        this._updateSearchBinding();
        this._hideNativePanel();
        this._destroyScreens();
        for (const monitor of Main.layoutManager.monitors) {
            const position = this._settings.get_int('dock-position');
            const screen = { monitor, position, dockDocked: false,
                popupSide: [St.Side.TOP, St.Side.LEFT, St.Side.RIGHT][position],
                hoverAnimationUpdates: new Set() };
            this._screens.push(screen);
            this._createPanel(screen);
            if (this._settings.get_boolean('show-dock')) {
                screen.tooltip = new St.Label({ style_class: 'dash-label macos-dock-tooltip', visible: false });
                screen.tooltip.clutter_text.line_wrap = true;
                screen.tooltip.clutter_text.line_wrap_mode = Pango.WrapMode.WORD_CHAR;
                Main.layoutManager.addTopChrome(screen.tooltip);
                screen.dock = new St.BoxLayout({
                    style_class: 'dash-background macos-dock',
                    clip_to_view: false,
                    style: `padding-top: ${this._settings.get_int('dock-padding-top')}px; ` +
                        `padding-bottom: ${this._settings.get_int('dock-padding-bottom')}px; ` +
                        `padding-left: ${this._settings.get_int('dock-padding-horizontal')}px; ` +
                        `padding-right: ${this._settings.get_int('dock-padding-horizontal')}px; ` +
                        `spacing: ${this._settings.get_int('dock-item-spacing')}px;`,
                    reactive: true,
                    orientation: position === 0 ? Clutter.Orientation.HORIZONTAL : Clutter.Orientation.VERTICAL,
                });
                screen.dock.add_style_class_name(this._dockRadiusClass());
                if (position !== 0)
                    screen.dock.add_style_class_name('macos-dock-vertical');
                screen.dockContainer = new St.ScrollView({
                    child: screen.dock,
                    clip_to_allocation: true,
                    reactive: true,
                    track_hover: true,
                    hscrollbar_policy: position === 0 ? St.PolicyType.EXTERNAL : St.PolicyType.NEVER,
                    vscrollbar_policy: position === 0 ? St.PolicyType.NEVER : St.PolicyType.EXTERNAL,
                });
                Main.layoutManager.addChrome(screen.dockContainer, { trackFullscreen: true });
                screen.dockContainer.connect('notify::hover', () => {
                    for (const update of screen.hoverAnimationUpdates)
                        update();
                });
                this._configureDockBackground(screen);
                screen.dockAdjustmentSignals = [];
                for (const adjustment of [screen.dockContainer.hadjustment, screen.dockContainer.vadjustment]) {
                    if (!adjustment)
                        continue;
                    const id = adjustment.connect('notify::value', () => this._updateDockIconGeometries(screen));
                    screen.dockAdjustmentSignals.push([adjustment, id]);
                }
                if (this._settings.get_boolean('reserve-dock-space')) {
                    screen.dockReservation = new St.Widget({
                        opacity: 0,
                        reactive: false,
                        can_focus: false,
                    });
                }
                if (this._settings.get_boolean('dock-autohide') ||
                    this._settings.get_boolean('dock-hide-when-covered')) {
                    screen.edge = new St.Widget({ reactive: true, track_hover: true, width: 10, height: 10 });
                    Main.layoutManager.addChrome(screen.edge, { trackFullscreen: true });
                    screen.edge.connect('notify::hover', () => {
                        if (screen.edge.hover) {
                            if (screen.dockCovered)
                                screen.dockPeek = true;
                            this._revealDock(screen);
                        }
                        else {
                            this._queueDockHide(screen);
                        }
                    });
                    screen.dockContainer.connect('notify::hover', () => {
                        if (screen.dockContainer.hover)
                            this._revealDock(screen);
                        else
                            this._queueDockHide(screen);
                    });
                    if (this._settings.get_boolean('dock-autohide'))
                        this._hideDock(screen);
                }
                Main.ctrlAltTabManager.addGroup(screen.dockContainer, `Dock - écran ${monitor.index + 1}`, 'shell-focus-dash-symbolic', {
                    proxy: screen.edge ?? screen.dockContainer,
                    focusCallback: () => {
                        if (screen.monitor.inFullscreen)
                            return;
                        this._revealDock(screen);
                        screen.dockContainer.navigate_focus(null, St.DirectionType.TAB_FORWARD, false);
                    },
                });
                screen.dockKeyController = new Clutter.KeyController();
                screen.dockKeyController.connect('key-press', () => {
                    const [, key] = screen.dockKeyController.get_key();
                    if (key !== Clutter.KEY_Escape)
                        return Clutter.EVENT_PROPAGATE;
                    screen.tooltip.hide();
                    global.display.focus_default_window(global.get_current_time());
                    this._queueDockHide(screen);
                    return Clutter.EVENT_STOP;
                });
                screen.dockContainer.add_action(screen.dockKeyController);
            }
        }
        this._syncDockCoverageWindows();
        this._rebuildDock();
        this._updateActiveApp();
        this._updateClocks();
        this._syncTrashTracking();
        this._updateDockCoverage();
        this._restoreDockFocus(focus);
        this._syncDesktopWidgets();
    }
    _hideNativePanel() {
        Main.panel.hide();
        Main.panel.reactive = false;
    }
    _restoreNativePanel() {
        if (!this._nativePanelState)
            return;
        Main.panel.visible = this._nativePanelState.visible;
        Main.panel.reactive = this._nativePanelState.reactive;
        this._nativePanelState = null;
    }
    _syncTrashTracking() {
        if (!this._settings.get_boolean('show-dock') || !this._settings.get_boolean('show-dock-shortcuts') ||
            !this._settings.get_boolean('shortcut-trash')) {
            this._stopTrashTracking();
            return;
        }
        if (this._trashFile)
            return;
        this._trashFile = Gio.File.new_for_uri('trash:///');
        try {
            this._trashMonitor = this._trashFile.monitor_directory(Gio.FileMonitorFlags.NONE, null);
            this._trashMonitorId = this._trashMonitor.connect('changed', () => {
                if (this._trashRefreshSource)
                    return;
                this._trashRefreshSource = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 150, () => {
                    this._trashRefreshSource = 0;
                    this._refreshTrash();
                    return GLib.SOURCE_REMOVE;
                });
            });
        }
        catch {
            this._trashPollSource = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 15, () => {
                this._refreshTrash();
                return GLib.SOURCE_CONTINUE;
            });
        }
        this._refreshTrash();
    }
    _refreshTrash() {
        if (!this._trashFile)
            return;
        if (this._trashRequest) {
            this._trashDirty = true;
            return;
        }
        const token = new Gio.Cancellable();
        this._trashRequest = token;
        this._trashFile.query_info_async('trash::item-count', Gio.FileQueryInfoFlags.NONE, GLib.PRIORITY_DEFAULT, token, (file, result) => {
            let count = null;
            try {
                const info = file.query_info_finish(result);
                if (info.has_attribute('trash::item-count'))
                    count = info.get_attribute_uint32('trash::item-count');
            }
            catch {
                count = null;
            }
            if (this._trashRequest !== token)
                return;
            this._trashRequest = null;
            this._trashCount = count;
            this._updateTrashButtons();
            if (this._trashDirty) {
                this._trashDirty = false;
                this._refreshTrash();
            }
        });
    }
    _stopTrashTracking() {
        this._trashRequest?.cancel();
        this._trashRequest = null;
        if (this._trashMonitor) {
            this._trashMonitor.disconnect(this._trashMonitorId);
            this._trashMonitor.cancel();
        }
        this._trashMonitor = null;
        for (const id of [this._trashRefreshSource, this._trashPollSource]) {
            if (id)
                GLib.source_remove(id);
        }
        this._trashRefreshSource = 0;
        this._trashPollSource = 0;
        this._trashFile = null;
        this._trashDirty = false;
        this._trashCount = null;
    }
    _trashDescription() {
        if (this._trashCount === null)
            return 'Corbeille : état indisponible';
        if (this._trashCount === 0)
            return 'Corbeille vide';
        return `Corbeille : ${this._trashCount} élément${this._trashCount > 1 ? 's' : ''}`;
    }
    _updateTrashButtons() {
        for (const screen of this._screens) {
            if (!screen.trashButton)
                continue;
            screen.trashButton.get_child().icon_name = this._trashCount > 0 ? 'user-trash-full' : 'user-trash';
            screen.trashButton.accessible_name = this._trashDescription();
        }
    }
    _destroyScreens() {
        for (const screen of this._screens) {
            screen.disposed = true;
            for (const id of screen.dropSources ?? [])
                GLib.source_remove(id);
            screen.dropSources?.clear();
            this._clearDockIconGeometry(screen);
            for (const [adjustment, id] of screen.dockAdjustmentSignals ?? [])
                adjustment.disconnect(id);
            if (screen.menuButton) {
                Main.panel.menuManager.removeMenu(screen.menuButton.menu);
                if (screen.menuButton === this._menu)
                    screen.panel?.remove_child(screen.menuButton.container);
            }
            if (screen.sessionButton)
                Main.panel.menuManager.removeMenu(screen.sessionButton.menu);
            if (screen.appLabel === this._activeAppLabel)
                screen.panel?.remove_child(screen.appLabel);
            if (screen.transferLabel === this._transferLabel)
                screen.panel?.remove_child(screen.transferLabel);
            this._cancelDockHide(screen);
            screen.edge?.destroy();
            screen.dockReservation?.destroy();
            for (const button of screen.statusButtons ?? []) {
                button.statusController?.destroy();
                Main.panel.menuManager.removeMenu(button.statusMenu);
                button.statusMenu.destroy();
            }
            screen.magnificationBackground?.destroy();
            screen.dockContainer?.destroy();
            screen.tooltip?.destroy();
            screen.panel?.destroy();
        }
        this._screens = [];
    }
    _updateWindowButtons() {
        if (!this._settings.get_boolean('window-buttons-left')) {
            this._restoreWindowButtons();
            return;
        }
        if (this._settings.get_strv('window-button-layout-backup').length > 0)
            return;
        this._windowSettings ??= new Gio.Settings({ schema_id: 'org.gnome.desktop.wm.preferences' });
        if (!this._windowSettings.is_writable('button-layout')) {
            Main.notifyError('Disposition des boutons indisponible', 'Le réglage système est verrouillé.');
            return;
        }
        const previous = this._windowSettings.get_user_value('button-layout');
        const backup = previous ? ['user', previous.unpack()] : ['default'];
        if (!this._settings.set_strv('window-button-layout-backup', backup))
            return;
        if (!this._windowSettings.set_string('button-layout', 'close,minimize,maximize:'))
            this._settings.set_strv('window-button-layout-backup', []);
    }
    _restoreWindowButtons() {
        const backup = this._settings.get_strv('window-button-layout-backup');
        if (backup.length === 0)
            return;
        this._windowSettings ??= new Gio.Settings({ schema_id: 'org.gnome.desktop.wm.preferences' });
        if (this._windowSettings.get_string('button-layout') === 'close,minimize,maximize:') {
            if (!this._windowSettings.is_writable('button-layout'))
                return;
            if (backup[0] === 'default')
                this._windowSettings.reset('button-layout');
            else if (backup[0] === 'user' && backup.length === 2 &&
                !this._windowSettings.set_string('button-layout', backup[1]))
                return;
        }
        this._settings.set_strv('window-button-layout-backup', []);
    }
    _updateSearchBinding() {
        if (this._searchBinding)
            Main.wm.removeKeybinding('spotlight-search');
        this._searchBinding = false;
        if (this._settings.get_boolean('enable-spotlight')) {
            const action = Main.wm.addKeybinding('spotlight-search', this._settings, Meta.KeyBindingFlags.IGNORE_AUTOREPEAT, Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => Main.overview.focusSearch());
            this._searchBinding = action !== Meta.KeyBindingAction.NONE;
        }
    }
    _rebuildDock() {
        const focus = this._captureDockFocus();
        const favorites = this._favorites.getFavorites();
        const favoriteIds = new Set(favorites.map(app => app.get_id()));
        const running = this._settings.get_boolean('show-running-apps')
            ? this._appSystem.get_running() : [];
        const workspaceApps = this._settings.get_boolean('dock-current-workspace');
        const workspace = workspaceApps ? global.workspace_manager.get_active_workspace() : null;
        const tracking = this._settings.get_boolean('show-dock') && this._settings.get_boolean('show-running-apps');
        this._syncWorkspaceSignals(tracking ? workspace : null);
        this._syncRunningAppSignals(workspaceApps && tracking ? running : []);
        const iconSize = this._settings.get_int('icon-size');
        const iconPadding = this._settings.get_int('dock-icon-padding');
        const dockFolders = this._settings.get_strv('dock-folders');
        const appFolders = readAppFolders(this._settings);
        const groupedApps = new Set(appFolders.flatMap(folder => folder.apps));
        const visibleFavorites = favorites.filter(app => !groupedApps.has(app.get_id()));
        const shortcuts = new Set(this._settings.get_boolean('show-dock-shortcuts')
            ? ['overview', 'desktop', 'files', 'downloads', 'trash']
                .filter(name => this._settings.get_boolean(`shortcut-${name}`)) : []);
        const downloads = shortcuts.has('downloads')
            ? GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) : null;
        if (!downloads)
            shortcuts.delete('downloads');
        for (const screen of this._screens) {
            if (!screen.dock)
                continue;
            const menuOpen = (screen.appButtons ?? []).some(button => button._menu?.isOpen) ||
                (screen.shortcutMenus ?? []).some(menu => menu.isOpen);
            if (menuOpen || screen.reorder) {
                screen.rebuildPending = true;
                for (const button of screen.appButtons ?? []) {
                    if (button.app.state === Shell.AppState.STARTING)
                        button.add_style_pseudo_class('starting');
                    else
                        button.remove_style_pseudo_class('starting');
                }
                continue;
            }
            screen.rebuildPending = false;
            screen.tooltip.hide();
            screen.hoverAnimationUpdates.clear();
            screen.dock.destroy_all_children();
            screen.appButtons = [];
            screen.shortcutMenus = [];
            screen.desktopButton = null;
            screen.trashButton = null;
            screen.folderButtons = [];
            const apps = [...visibleFavorites, ...running.filter(app => !groupedApps.has(app.get_id()) && !favoriteIds.has(app.get_id()) && (!workspaceApps || app.get_windows().some(window => !window.skip_taskbar && window.located_on_workspace(workspace))))];
            for (const app of apps) {
                const button = new AppDisplay.AppIcon(app, {
                    setSizeManually: true,
                    showLabel: false,
                    isDraggable: false,
                    popupMenuSide: screen.popupSide,
                });
                button.add_style_class_name('macos-dock-item');
                button.dockFocusKey = `app:${app.get_id()}`;
                button.accessible_name = this._appDescription(app, screen);
                if (app.state === Shell.AppState.STARTING)
                    button.add_style_pseudo_class('starting');
                button.icon.setIconSize(iconSize);
                button.set_style(`padding: ${iconPadding}px;`);
                const updateIconGeometry = () => this._updateDockIconGeometry(screen, button);
                button.connect('notify::allocation', updateIconGeometry);
                button.connect('destroy', () => this._clearAppDockIconGeometry(screen, app));
                const nativeAnimateLaunch = button.animateLaunch?.bind(button) ?? (() => { });
                button.animateLaunch = () => {
                    if (!this._settings.get_boolean('dock-launch-animation'))
                        return;
                    const mode = this._settings.get_int('dock-launch-mode');
                    if (mode === 1 || (mode === 0 && this._settings.get_int('dock-hover-animation') === 3))
                        this._animateDockLaunch(button, screen);
                    else
                        nativeAnimateLaunch();
                };
                const activate = button.activate.bind(button);
                button.activate = mouseButton => {
                    if (!this._activateAppFromDock(app, mouseButton, screen))
                        activate(mouseButton);
                };
                button.notificationBadge = new St.Label({
                    style_class: 'macos-notification-badge',
                    x_align: Clutter.ActorAlign.START,
                    y_align: Clutter.ActorAlign.START,
                    visible: false,
                });
                button.get_child().add_child(button.notificationBadge);
                let badgePositionSource = 0;
                const positionBadge = () => {
                    this._positionNotificationBadge(button);
                    this._positionTransferProgress(button);
                    if (!badgePositionSource) {
                        badgePositionSource = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                            badgePositionSource = 0;
                            this._positionNotificationBadge(button);
                            this._positionTransferProgress(button);
                            return GLib.SOURCE_REMOVE;
                        });
                    }
                };
                for (const signal of ['notify::allocation', 'notify::scale-x', 'notify::scale-y',
                    'notify::translation-x', 'notify::translation-y'])
                    button.icon.icon.connect(signal, positionBadge);
                button.get_child().connect('notify::allocation', positionBadge);
                button.notificationBadge.connect('notify::allocation', positionBadge);
                button.connect('destroy', () => {
                    if (badgePositionSource)
                        GLib.source_remove(badgePositionSource);
                    badgePositionSource = 0;
                });
                button.progressBar = new St.Widget({
                    style_class: 'macos-transfer-progress',
                    style: `width: ${iconSize}px;`,
                    layout_manager: new Clutter.BinLayout(),
                    clip_to_allocation: true,
                    x_align: Clutter.ActorAlign.START,
                    y_align: Clutter.ActorAlign.START,
                    visible: false,
                });
                button.progressBar.set_pivot_point(0, 0);
                button.progressFill = new St.Widget({
                    style_class: 'macos-transfer-progress-fill',
                    x_expand: true,
                    y_expand: true,
                    scale_x: 0,
                });
                button.progressFill.set_pivot_point(0, 0);
                button.progressBar.add_child(button.progressFill);
                button.get_child().add_child(button.progressBar);
                button.progressBar.connect('notify::allocation', positionBadge);
                this._attachTooltip(screen, button, () => this._appDescription(app, screen));
                let summarySignal = 0;
                const updateSummary = () => {
                    const count = this._windowsForDock(app, screen).length;
                    if (!button.windowSummary) {
                        button.windowSummary = new PopupMenu.PopupMenuItem('', { reactive: false, can_focus: false });
                        button._menu.addMenuItem(button.windowSummary, 0);
                    }
                    button.windowSummary.label.text = `${count} fenêtre${count === 1 ? '' : 's'} dans ce Dock`;
                    button.windowSummary.accessible_name = button.windowSummary.label.text;
                    this._updateNotificationCounts();
                };
                const disconnectSummary = () => {
                    if (summarySignal)
                        app.disconnect(summarySignal);
                    summarySignal = 0;
                };
                button.connect('menu-state-changed', (actor, opened) => {
                    if (screen.disposed) {
                        disconnectSummary();
                        return;
                    }
                    screen.tooltip.hide();
                    if (opened) {
                        button._menu.actor.add_style_class_name('macos-popup');
                        this._revealDock(screen);
                        updateSummary();
                        if (!summarySignal)
                            summarySignal = app.connect('windows-changed', updateSummary);
                    }
                    else {
                        disconnectSummary();
                        this._finishDockMenu(screen);
                        this._queueDockHide(screen);
                    }
                });
                button.connect('destroy', disconnectSummary);
                screen.appButtons.push(button);
                screen.dock.add_child(button);
            }
            const showApps = new St.Button({
                style_class: 'macos-dock-item macos-show-apps',
                accessible_name: 'Afficher les applications',
                can_focus: true,
                reactive: true,
                track_hover: true,
            });
            showApps.set_child(new St.Icon({ icon_name: 'view-app-grid-symbolic', icon_size: iconSize }));
            showApps.set_style(`padding: ${iconPadding}px;`);
            showApps.dockFocusKey = 'shortcut:applications';
            showApps.connect('clicked', () => Main.overview.showApps());
            this._attachLaunchpadMenu(screen, showApps);
            this._attachTooltip(screen, showApps, 'Applications');
            screen.dock.add_child(showApps);
            if (shortcuts.size > 0) {
                if (shortcuts.has('overview'))
                    this._addDockShortcut(screen, 'Fenêtres et espaces de travail', 'view-paged-symbolic', iconSize, () => Main.overview.show());
                if (shortcuts.has('desktop'))
                    screen.desktopButton = this._addDockShortcut(screen, () => this._desktopActionName(), 'user-desktop', iconSize, () => this._toggleDesktop());
                if (shortcuts.has('files')) {
                    const button = this._addDockShortcut(screen, 'Fichiers', 'system-file-manager', iconSize, () => this._openLocation(Gio.File.new_for_path(GLib.get_home_dir()).get_uri()));
                    this._attachPlacesMenu(screen, button);
                }
                if (shortcuts.has('downloads')) {
                    const button = this._addDockShortcut(screen, 'Téléchargements', 'folder-download', iconSize, () => this._openLocation(Gio.File.new_for_path(downloads).get_uri()));
                    this._attachDownloadsMenu(screen, button, downloads);
                }
                if (shortcuts.has('trash'))
                    screen.trashButton = this._addDockShortcut(screen, () => this._trashDescription(), 'user-trash', iconSize, () => this._openLocation('trash:///'));
            }
            for (const uri of dockFolders)
                this._addDockFolder(screen, uri, iconSize, iconPadding);
            for (const folder of appFolders)
                this._addDockAppFolder(screen, folder, iconSize, iconPadding);
            this._widgetRuntime.makeDock(screen, iconSize, iconPadding);
            this._configureDockOrder(screen);
            this._configureDockMagnification(screen);
        }
        this._positionDock();
        this._updateDockIconGeometries();
        this._updateActiveApp();
        this._updateNotificationCounts();
        this._updateTransferIndicators();
        this._updateTrashButtons();
        this._updateAttentionIndicators();
        this._restoreDockFocus(focus);
    }
    _positionNotificationBadge(button) {
        const icon = button.icon.icon;
        const badge = button.notificationBadge;
        const [iconX, iconY] = icon.get_transformed_position();
        const [iconWidth, iconHeight] = icon.get_transformed_size();
        if (iconWidth <= 0 || iconHeight <= 0)
            return;
        const [success, x, y] = button.get_child().transform_stage_point(iconX + iconWidth, iconY);
        if (!success || !Number.isFinite(x) || !Number.isFinite(y))
            return;
        const [, width] = badge.get_preferred_width(-1);
        const [, height] = badge.get_preferred_height(width);
        const allocation = badge.get_allocation_box();
        if (![width, height, allocation.x1, allocation.y1].every(Number.isFinite))
            return;
        badge.translation_x = x - allocation.x1 - width / 2;
        badge.translation_y = y - allocation.y1 - height / 2;
    }
    _positionTransferProgress(button) {
        const bar = button.progressBar;
        if (!bar || !bar.visible || button.destroyed)
            return;
        const icon = button.icon.icon;
        const [iconX, iconY] = icon.get_transformed_position();
        const [iconWidth, iconHeight] = icon.get_transformed_size();
        const container = button.get_child();
        const [success, x, bottom] = container.transform_stage_point(iconX, iconY + iconHeight);
        const [rightSuccess, right] = container.transform_stage_point(iconX + iconWidth, iconY + iconHeight);
        const [, height] = bar.get_preferred_height(-1);
        const allocation = bar.get_allocation_box();
        if (!success || !rightSuccess || iconWidth <= 0 || iconHeight <= 0 ||
            ![x, bottom, right, height, allocation.x1, allocation.y1].every(Number.isFinite))
            return;
        bar.scale_x = (right - x) / this._settings.get_int('icon-size');
        bar.translation_x = x - allocation.x1;
        bar.translation_y = bottom - height - allocation.y1;
    }
    _updateDockIconGeometries(screen = null) {
        for (const candidate of screen ? [screen] : this._screens) {
            for (const button of candidate.appButtons ?? [])
                this._updateDockIconGeometry(candidate, button);
        }
    }
    _updateDockIconGeometry(screen, button) {
        const { monitor, dockContainer } = screen;
        const [x, y] = button.get_transformed_position();
        const [width, height] = button.get_transformed_size();
        const [viewX, viewY] = dockContainer.get_transformed_position();
        const [viewWidth, viewHeight] = dockContainer.get_transformed_size();
        const visible = dockContainer.visible !== false && !monitor.inFullscreen &&
            x + width > viewX && x < viewX + viewWidth &&
            y + height > viewY && y < viewY + viewHeight;
        const geometry = visible && width > 0 && height > 0
            ? new Mtk.Rectangle({
                x: Math.round(x),
                y: Math.round(y),
                width: Math.round(width),
                height: Math.round(height),
            }) : null;
        for (const window of button.app.get_windows()) {
            if (typeof window.get_monitor === 'function' && window.get_monitor() === monitor.index &&
                typeof window.set_icon_geometry === 'function')
                window.set_icon_geometry(geometry);
        }
    }
    _clearAppDockIconGeometry(screen, app) {
        for (const window of app.get_windows()) {
            if (typeof window.get_monitor === 'function' && window.get_monitor() === screen.monitor.index &&
                typeof window.set_icon_geometry === 'function')
                window.set_icon_geometry(null);
        }
    }
    _clearDockIconGeometry(screen) {
        for (const button of screen.appButtons ?? []) {
            this._clearAppDockIconGeometry(screen, button.app);
        }
    }
    _desktopActionName() {
        return this._desktopWindows.has(global.workspace_manager.get_active_workspace())
            ? 'Restaurer les fenêtres' : 'Afficher le bureau';
    }
    _updateDesktopButtons() {
        for (const screen of this._screens) {
            if (screen.desktopButton)
                screen.desktopButton.accessible_name = this._desktopActionName();
        }
    }
    _toggleDesktop() {
        const workspace = global.workspace_manager.get_active_workspace();
        Main.overview.hide();
        if (this._desktopWindows.has(workspace)) {
            this._restoreDesktop(workspace);
            return;
        }
        const windows = workspace.list_windows().filter(window => !window.minimized && !window.skip_taskbar && window.can_minimize());
        if (windows.length === 0)
            return;
        const group = { windows: new Map(), focusedWindow: global.display.focus_window };
        this._desktopWindows.set(workspace, group);
        for (const window of windows) {
            const ids = [
                window.connect('unmanaged', () => this._forgetDesktopWindow(workspace, window)),
                window.connect('notify::minimized', () => {
                    if (!window.minimized)
                        this._forgetDesktopWindow(workspace, window);
                }),
            ];
            group.windows.set(window, ids);
            window.minimize();
        }
        this._updateDesktopButtons();
    }
    _forgetDesktopWindow(workspace, window) {
        const group = this._desktopWindows.get(workspace);
        const ids = group?.windows.get(window);
        if (!ids)
            return;
        for (const id of ids)
            window.disconnect(id);
        group.windows.delete(window);
        if (group.windows.size === 0)
            this._desktopWindows.delete(workspace);
        this._updateDesktopButtons();
    }
    _restoreDesktop(workspace, restoreFocus = true) {
        const group = this._desktopWindows.get(workspace);
        if (!group)
            return;
        this._desktopWindows.delete(workspace);
        let focusedWindowRestored = false;
        for (const [window, ids] of group.windows) {
            for (const id of ids)
                window.disconnect(id);
            if (window.minimized && window.located_on_workspace(workspace)) {
                window.unminimize();
                focusedWindowRestored ||= window === group.focusedWindow;
            }
        }
        if (restoreFocus && focusedWindowRestored &&
            global.workspace_manager.get_active_workspace() === workspace)
            Main.activateWindow(group.focusedWindow);
        this._updateDesktopButtons();
    }
    _activateAppFromDock(app, mouseButton, screen) {
        const cycle = this._settings.get_boolean('dock-cycle-windows');
        const filtered = this._settings.get_boolean('dock-current-workspace');
        if ((!cycle && !filtered) || Main.overview.visible ||
            (mouseButton && mouseButton !== Clutter.BUTTON_PRIMARY))
            return false;
        const modifiers = Clutter.get_current_event()?.get_state() ?? 0;
        const shortcutModifiers = Clutter.ModifierType.CONTROL_MASK |
            Clutter.ModifierType.SHIFT_MASK | Clutter.ModifierType.MOD1_MASK |
            Clutter.ModifierType.SUPER_MASK;
        if (modifiers & shortcutModifiers)
            return false;
        const workspace = global.workspace_manager.get_active_workspace();
        const matching = filtered ? this._windowsForDock(app, screen)
            : app.get_windows().filter(window => !window.skip_taskbar && window.located_on_workspace(workspace));
        const windows = matching.filter(window => window.located_on_workspace(workspace))
            .sort((first, second) => first.get_stable_sequence() - second.get_stable_sequence());
        const focus = global.display.focus_window;
        const index = windows.indexOf(focus);
        if (cycle && windows.length > 1 && index >= 0) {
            Main.activateWindow(windows[(index + 1) % windows.length]);
            return true;
        }
        if (filtered && matching.length > 0) {
            const target = matching.includes(focus) ? focus
                : matching.find(window => window.located_on_workspace(workspace) && !window.minimized) ??
                    matching.find(window => window.located_on_workspace(workspace)) ?? matching[0];
            Main.activateWindow(target);
            return true;
        }
        return false;
    }
    _addDockWidget(screen, type, iconSize, iconPadding, instance = null) {
        if (type === 'clock' && !this._dockWallClock) {
            this._dockWallClock = new GnomeDesktop.WallClock({ time_only: true });
            this._dockClockSettings = new Gio.Settings({ schema_id: 'org.gnome.desktop.interface' });
            this._connect(this._dockWallClock, 'notify::clock', () => this._updateDockWidgets());
        }
        const square = instance && !instance.legacy ? instance.dockSize === 1
            : this._settings.get_value('dock-widget-sizes').deep_unpack()[type] === 1;
        const thickness = iconSize + iconPadding * 2;
        const length = square ? thickness : type === 'media'
            ? Math.max(180, Math.round(thickness * 4.5)) : Math.round(thickness * 2.5);
        const contentLength = length - iconPadding * 2;
        const horizontal = screen.position === 0;
        const content = new St.BoxLayout({
            style_class: `macos-dock-widget-content macos-dock-widget-${type}${iconSize < 32 ? ' macos-dock-widget-compact' : ''}${square ? ' macos-dock-widget-square' : ''}`,
            orientation: Clutter.Orientation.VERTICAL,
            width: contentLength,
            height: iconSize,
        });
        const primary = new St.Label({ style_class: 'macos-dock-widget-primary' });
        const secondary = new St.Label({ style_class: 'macos-dock-widget-secondary' });
        primary.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        secondary.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        const mediaView = type === 'media' ? this._createMediaView({ compact: !square, square, iconSize, screen }) : null;
        if (mediaView)
            content.add_child(mediaView);
        else {
            content.add_child(primary);
            content.add_child(secondary);
        }
        content.set_pivot_point(0.5, 0.5);
        content.rotation_angle_z = horizontal || type === 'media' ? 0 : screen.position === 1 ? 90 : -90;
        if (!horizontal && type === 'media') {
            content.set_size(iconSize, contentLength);
            if (!square)
                content.add_style_class_name('macos-media-vertical-content');
        }
        const viewport = new St.Widget({ layout_manager: new Clutter.FixedLayout(),
            width: horizontal ? length : thickness, height: horizontal ? thickness : length });
        viewport.add_child(content);
        content.set_position(horizontal || type === 'media' ? iconPadding : (thickness - contentLength) / 2, horizontal || type === 'media' ? iconPadding : (length - iconSize) / 2);
        const button = new St.Button({ style_class: 'macos-dock-widget', child: viewport,
            accessible_name: type === 'media' ? 'Lecteur média' : type === 'clock' ? 'Horloge' : 'Date',
            can_focus: true, reactive: true, track_hover: true });
        button.set_size(horizontal ? length : thickness, horizontal ? thickness : length);
        button.dockFocusKey = `widget:${type}`;
        button.dockWidgetType = type;
        button.dockWidgetSquare = square;
        button.dockWidgetPrimary = primary;
        button.dockWidgetSecondary = secondary;
        button.mediaView = mediaView;
        button._delegate = {
            getDragActor: () => new Clutter.Clone({ source: viewport }),
            getDragActorSource: () => viewport,
        };
        if (mediaView) {
            mediaView.ownerButton = button;
            if (square)
                button.connect('clicked', () => button.shortcutMenu.toggle());
        }
        else
            button.connect('clicked', () => Main.panel.statusArea?.dateMenu?.menu?.toggle());
        this._attachTooltip(screen, button, () => button.accessible_name, { magnify: type !== 'media' });
        this._createShortcutMenu(screen, button, { onOpen: menu => {
                menu.removeAll();
                if (type === 'media') {
                    const item = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
                    item.add_child(this._createMediaView({ screen }));
                    menu.addMenuItem(item);
                    menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
                }
                for (const [size, title] of [[1, '1×1'], [0, 'Large']]) {
                    const item = menu.addAction(title, () => {
                        if (!this._settings.is_writable('dock-widget-sizes'))
                            return;
                        const sizes = this._settings.get_value('dock-widget-sizes').deep_unpack();
                        sizes[type] = size;
                        menu.close();
                        if (instance && !instance.legacy)
                            this._widgetRuntime.updateInstance(instance, { dockSize: size });
                        else
                            this._settings.set_value('dock-widget-sizes', new GLib.Variant('a{si}', sizes));
                    });
                    item.setOrnament((square ? 1 : 0) === size ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
                    item.setSensitive(this._settings.is_writable('dock-widget-sizes'));
                }
            } });
        screen.dock.add_child(button);
        this._updateDockWidget(button);
        return button;
    }
    _updateDockWidget(button) {
        if (!['clock', 'calendar', 'media'].includes(button.dockWidgetType))
            return;
        if (button.dockWidgetType === 'media') {
            this._refreshMediaWidgets();
            return;
        }
        const date = GLib.DateTime.new_now_local();
        if (button.dockWidgetType === 'clock') {
            button.dockWidgetPrimary.text = button.dockWidgetSquare
                ? date.format(this._dockClockSettings.get_string('clock-format') === '12h' ? '%I' : '%H')
                : this._dockWallClock.clock;
            button.dockWidgetSecondary.text = date.format(button.dockWidgetSquare ? '%M' : '%a %d %b');
            button.accessible_name = `Horloge ${this._dockWallClock.clock}`;
            if (!button.dockWidgetSquare && button.widgetConfig?.format && button.widgetConfig.format !== 'Systeme')
                button.dockWidgetPrimary.text = date.format(button.widgetConfig.format === '12 h' ? '%I:%M %p' : '%H:%M');
            button.dockWidgetSecondary.visible = button.dockWidgetSquare || button.widgetConfig?.['show-date'] !== false;
        }
        else {
            button.dockWidgetPrimary.text = date.format(button.dockWidgetSquare ? '%d' : '%d %b');
            button.dockWidgetSecondary.text = date.format(button.dockWidgetSquare ? '%b' : '%A');
            button.accessible_name = date.format('%A %d %B');
            button.dockWidgetSecondary.visible = button.dockWidgetSquare || button.widgetConfig?.['show-weekday'] !== false;
        }
    }
    _updateDockWidgets() {
        for (const screen of this._screens ?? []) {
            for (const button of screen.dock?.get_children() ?? []) {
                if (button.dockWidgetType)
                    this._updateDockWidget(button);
            }
        }
    }
    _addDockShortcut(screen, name, iconName, iconSize, callback) {
        const button = new St.Button({
            style_class: 'macos-dock-item',
            accessible_name: typeof name === 'function' ? name() : name,
            can_focus: true,
            reactive: true,
            track_hover: true,
            child: new St.Icon({ icon_name: iconName, icon_size: iconSize }),
        });
        button.set_style(`padding: ${this._settings.get_int('dock-icon-padding')}px;`);
        button.dockFocusKey = `shortcut:${iconName}`;
        this._attachTooltip(screen, button, name);
        button.connect('clicked', callback);
        screen.dock.add_child(button);
        return button;
    }
    _openLocation(uri) {
        Gio.AppInfo.launch_default_for_uri_async(uri, global.create_app_launch_context(global.get_current_time(), -1), null, (source, result) => {
            try {
                Gio.AppInfo.launch_default_for_uri_finish(result);
            }
            catch (error) {
                Main.notifyError('Impossible d’ouvrir cet emplacement', error.message);
            }
        });
    }
    _updateActiveApp() {
        const window = global.display.focus_window;
        if (window)
            this._forgetAttentionWindow(window);
        const isDesktop = window?.get_window_type?.() === Meta.WindowType.DESKTOP;
        const app = window && !isDesktop ? Shell.WindowTracker.get_default().get_window_app(window) : null;
        this._activeAppLabel.text = app?.get_name() ?? 'Finder';
        for (const screen of this._screens) {
            if (screen.appLabel) {
                screen.appLabel.text = this._activeAppLabel.text;
                this._applyPanelMetrics(screen);
            }
            for (const button of screen.appButtons ?? []) {
                if (button.app === app)
                    button.add_style_pseudo_class('active-app');
                else
                    button.remove_style_pseudo_class('active-app');
            }
        }
        this._updateDockIconGeometries();
    }
}
//# sourceMappingURL=extension.js.map