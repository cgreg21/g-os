import St from 'gi://St';
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {DockWindowPreview} from './windowPreviews.js';
export function withDockAppearance(Base) {
    return class extends Base {
        _attachTooltip(screen, button, text, { magnify = true, scroll = true } = {}) {
            if (magnify)
                this._attachMagnification(screen, button, button.icon?.icon ?? button.get_child());
            const update = (coordinates = null) => {
                if (button.windowPreview?.isOpen) {
                    screen.tooltip.hide();
                    return;
                }
                const hovered = button.hover && (!button.shouldShowTooltip || button.shouldShowTooltip());
                const focused = button.has_key_focus() && !button._menu?.isOpen && !button.shortcutMenu?.isOpen;
                if (!hovered && !focused) {
                    screen.tooltip.hide();
                    return;
                }
                screen.tooltip.text = typeof text === 'function' ? text() : text;
                screen.tooltip.show();
                const [buttonX, buttonY] = coordinates ?? button.get_transformed_position();
                const [buttonWidth, buttonHeight] = button.get_transformed_size();
                const [, width] = screen.tooltip.get_preferred_width(-1);
                const [, height] = screen.tooltip.get_preferred_height(width);
                const { monitor } = screen;
                let x = buttonX + (buttonWidth - width) / 2;
                let y = buttonY - height - 8;
                const magnifiedIcon = button.icon?.icon ?? button.get_child();
                const extra = magnify && this._settings.get_int('dock-hover-animation') === 4
                    ? Math.max(0, (button.magnificationScale ?? magnifiedIcon.scale_y ?? 1) - 1) *
                        this._settings.get_int('icon-size') : 0;
                y -= extra;
                if (screen.position === 1) {
                    x = buttonX + buttonWidth + 8 + extra;
                    y = buttonY + (buttonHeight - height) / 2;
                }
                else if (screen.position === 2) {
                    x = buttonX - width - 8 - extra;
                    y = buttonY + (buttonHeight - height) / 2;
                }
                screen.tooltip.set_position(Math.round(Math.max(monitor.x, Math.min(x, monitor.x + monitor.width - width))), Math.round(Math.max(monitor.y, Math.min(y, monitor.y + monitor.height - height))));
            };
            button.updateDockTooltip = update;
            button.connect('notify::hover', () => update());
            button.connect('key-focus-in', () => update(scroll ? this._scrollDockButtonIntoView(screen, button) : null));
            button.connect('key-focus-out', () => update());
            button.connect('clicked', () => screen.tooltip.hide());
            if (button.app && this._settings.get_boolean('dock-window-previews')) {
                button.windowPreview = new DockWindowPreview(button, screen, {
                    GLib, St, Clutter, PopupMenu, Pango,
                    menuManager: Main.panel.menuManager, uiGroup: Main.uiGroup,
                    getWindows: () => this._windowsForDock(button.app, screen),
                    getDelay: () => this._settings.get_int('dock-window-preview-delay'),
                    allowed: () => !screen.disposed && !screen.monitor.inFullscreen && !screen.reorder &&
                        screen.dockContainer.visible !== false && !Main.overview.visible && Main.sessionMode?.currentMode !== 'unlock-dialog' &&
                        !button._menu?.isOpen && !(screen.shortcutMenus ?? []).some(menu => menu.isOpen),
                    activate: window => Main.activateWindow(window), timestamp: () => global.get_current_time(),
                    onOpen: () => {
                        for (const other of this._screens) {
                            for (const candidate of other.appButtons ?? []) {
                                if (candidate !== button)
                                    candidate.windowPreview?.close();
                            }
                        }
                        screen.tooltip.hide();
                        this._revealDock(screen);
                    },
                    onClose: () => { if (!screen.disposed) this._queueDockHide(screen); },
                });
                const overviewSignal = Main.overview.connect('showing', () => button.windowPreview.close());
                button.connect('destroy', () => Main.overview.disconnect(overviewSignal));
            }
        }
        _scrollDockButtonIntoView(screen, button) {
            const horizontal = screen.position === 0;
            const adjustment = horizontal ? screen.dockContainer.hadjustment : screen.dockContainer.vadjustment;
            if (!adjustment || adjustment.page_size <= 0)
                return null;
            const [buttonX, buttonY] = button.get_transformed_position();
            const [viewX, viewY] = screen.dockContainer.get_transformed_position();
            const [width, height] = button.get_transformed_size();
            const begin = horizontal ? buttonX - viewX : buttonY - viewY;
            const extent = horizontal ? width : height;
            const delta = begin < 0 || extent > adjustment.page_size
                ? begin : Math.max(0, begin + extent - adjustment.page_size);
            const previous = adjustment.value;
            adjustment.value = Math.max(adjustment.lower, Math.min(adjustment.upper - adjustment.page_size, previous + delta));
            const shift = adjustment.value - previous;
            return horizontal ? [buttonX - shift, buttonY] : [buttonX, buttonY - shift];
        }
        _attachMagnification(screen, button, icon) {
            const animation = this._settings.get_int('dock-hover-animation');
            if (animation === 0 || animation === 4)
                return;
            const hoverDuration = this._settings.get_int('dock-hover-duration');
            const strength = this._settings.get_int('dock-hover-strength') / 100;
            const motion = St.Settings.get();
            icon.set_pivot_point(0.5, 0.5);
            const update = (soft = false) => {
                const reduced = 'ReducedMotion' in St &&
                    (motion.reduced_motion ?? motion.reducedMotion) === St.ReducedMotion.REDUCE;
                const animated = motion.enable_animations && !reduced;
                if (button.dockLaunchAnimating)
                    return;
                const engaged = animated && screen.dockContainer.hover && button.hover;
                const state = `${animated}:${engaged}`;
                if (button._dockHoverState === state && !soft)
                    return;
                button._dockHoverState = state;
                let scale = 1;
                let translationY = 0;
                let duration = animated ? hoverDuration : 0;
                let mode = engaged ? Clutter.AnimationMode.EASE_OUT_QUAD : Clutter.AnimationMode.EASE_IN_OUT_QUAD;
                if (engaged) {
                    if (animation === 1) {
                        scale = 1 + 0.18 * strength;
                    }
                    else if (animation === 2) {
                        scale = 1 + 0.08 * strength;
                        translationY = -8 * strength;
                        duration = Math.round(hoverDuration * 150 / 180);
                    }
                    else if (animation === 3) {
                        scale = 1 + 0.12 * strength;
                        translationY = -4 * strength;
                        if (!soft) {
                            duration = hoverDuration * 2;
                            mode = Clutter.AnimationMode.EASE_OUT_BOUNCE;
                        }
                    }
                }
                icon.ease({
                    scale_x: scale,
                    scale_y: scale,
                    translation_y: translationY,
                    duration,
                    mode,
                });
            };
            button._dockHoverAnimationUpdate = update;
            screen.hoverAnimationUpdates.add(update);
            button.connect('notify::hover', () => update());
            button.connect('key-focus-in', () => update());
            button.connect('key-focus-out', () => update());
            const id = motion.connect('notify', update);
            button.connect('destroy', () => {
                motion.disconnect(id);
                icon.remove_all_transitions();
            });
        }
        _dockRadiusClass() {
            return `macos-dock-radius-${this._settings.get_int('dock-border-radius')}`;
        }
        _configureDockBackground(screen) {
            screen.dock.add_style_class_name('macos-dock-magnification-content');
            screen.magnificationBackground = new St.Widget({
                style_class: `macos-dock ${this._dockRadiusClass()}`,
                reactive: false,
                visible: screen.dockContainer.visible !== false,
            });
            if (!this._settings.get_boolean('dock-show-border'))
                screen.magnificationBackground.add_style_class_name('macos-dock-no-border');
            if (!this._settings.get_boolean('dock-show-shadow'))
                screen.magnificationBackground.add_style_class_name('macos-dock-no-shadow');
            const backgroundStyle = ['', 'macos-dock-background-subtle', 'macos-dock-background-opaque',
                'macos-dock-background-transparent'][this._settings.get_int('dock-background-style')];
            if (backgroundStyle)
                screen.magnificationBackground.add_style_class_name(backgroundStyle);
            Main.layoutManager.addChrome(screen.magnificationBackground, { trackFullscreen: true });
            Main.uiGroup.set_child_below_sibling(screen.magnificationBackground, screen.dockContainer);
            const update = () => {
                if (screen.disposed || screen.magnificationBackgroundSource)
                    return;
                screen.magnificationBackgroundSource = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                    this._updateMagnificationBackground(screen);
                    screen.magnificationBackgroundSource = 0;
                    return GLib.SOURCE_REMOVE;
                });
            };
            screen.dockContainer.connect('notify::allocation', update);
            screen.dock.connect('notify::allocation', update);
            screen.magnificationBackground.connect('destroy', () => {
                if (screen.magnificationBackgroundSource)
                    GLib.source_remove(screen.magnificationBackgroundSource);
                screen.magnificationBackgroundSource = 0;
            });
        }
        _configureDockMagnification(screen) {
            if (this._settings.get_int('dock-hover-animation') !== 4)
                return;
            const padding = Math.ceil(this._settings.get_int('icon-size') * 0.8);
            screen.magnificationPadding = padding;
            screen.dockContainer.set_style(screen.position === 0
                ? `padding: ${padding}px ${padding * 3}px 0;`
                : screen.position === 1
                    ? `padding: ${padding * 3}px ${padding}px ${padding * 3}px 0;`
                    : `padding: ${padding * 3}px 0 ${padding * 3}px ${padding}px;`);
            screen.dock.clip_to_allocation = false;
            screen.dockContainer.clip_to_allocation = true;
            if (!screen.magnificationConnected) {
                screen.magnificationConnected = true;
                screen.dockContainer.connect('motion-event', (actor, event) => {
                    const following = screen.magnificationPoint !== null;
                    screen.magnificationPoint = event.get_coords();
                    this._updateDockMagnification(screen, screen.magnificationPoint, false, following);
                    return Clutter.EVENT_PROPAGATE;
                });
                screen.dockContainer.connect('notify::hover', () => {
                    if (!screen.dockContainer.hover) {
                        screen.magnificationPoint = null;
                        this._updateDockMagnification(screen);
                    }
                });
                const motion = St.Settings.get();
                const signal = motion.connect('notify', () => this._updateDockMagnification(screen));
                screen.dockContainer.connect('destroy', () => motion.disconnect(signal));
            }
            for (const button of screen.dock.get_children().filter(candidate => candidate.dockFocusKey)) {
                const icon = button.icon?.icon ?? button.get_child();
                this._prepareMagnificationIcon(icon);
                icon.set_pivot_point(screen.position === 0 ? 0.5 : screen.position === 1 ? 0 : 1, screen.position === 0 ? 1 : 0.5);
                button.connect('notify::hover', () => {
                    this._updateDockMagnification(screen, screen.magnificationPoint, false, screen.magnificationPoint !== null);
                });
                for (const signal of ['key-focus-in', 'key-focus-out']) {
                    button.connect(signal, () => {
                        screen.magnificationPoint = null;
                        this._updateDockMagnification(screen);
                    });
                }
            }
            screen.magnificationPoint = null;
            this._updateDockMagnification(screen);
        }
        _prepareMagnificationIcon(actor) {
            if (actor instanceof St.Icon && actor.icon_size > 0) {
                const size = actor.icon_size;
                actor.icon_size = Math.ceil(size * 1.8);
                actor.set_size(size, size);
            }
            else {
                for (const child of actor.get_children())
                    this._prepareMagnificationIcon(child);
            }
        }
        _updateDockMagnification(screen, point = screen.magnificationPoint, reset = false, following = false) {
            if (!screen.magnificationConnected || screen.disposed)
                return;
            if (reset)
                screen.magnificationPoint = null;
            const buttons = screen.dock.get_children().filter(button => button.dockFocusKey);
            if (buttons.length === 0)
                return;
            const axis = screen.position === 0 ? 0 : 1;
            const centers = buttons.map(button => {
                const position = button.get_transformed_position();
                const size = button.get_transformed_size();
                const shift = axis === 0 ? button.translation_x ?? 0 : button.translation_y ?? 0;
                return position[axis] - shift + size[axis] / 2;
            });
            if (!centers.every(Number.isFinite))
                return;
            const hovered = buttons.findIndex(button => button.hover);
            const coordinate = point && screen.dockContainer.hover ? point[axis]
                : screen.dockContainer.hover && hovered >= 0 ? centers[hovered] : null;
            const motion = St.Settings.get();
            const reduced = 'ReducedMotion' in St &&
                (motion.reduced_motion ?? motion.reducedMotion) === St.ReducedMotion.REDUCE;
            const animated = motion.enable_animations && !reduced && !reset;
            const engaged = animated && coordinate !== null && !screen.reorder && screen.dockContainer.visible !== false &&
                !screen.monitor.inFullscreen && !(screen.shortcutMenus ?? []).some(menu => menu.isOpen) &&
                !(screen.appButtons ?? []).some(button => button._menu?.isOpen);
            const size = this._settings.get_int('icon-size');
            const strength = this._settings.get_int('dock-hover-strength') / 100;
            const scales = centers.map((center, index) => engaged && !buttons[index].dockWidgetType
                ? 1 + 0.8 * strength * Math.exp(-Math.pow((center - coordinate) / (size * 2.5), 2)) : 1);
            let extra = 0;
            const offsets = scales.map(scale => {
                const growth = size * (scale - 1);
                const offset = extra + growth / 2;
                extra += growth;
                return offset;
            });
            let left = -1;
            let right = -1;
            if (coordinate !== null) {
                centers.forEach((center, index) => {
                    if (center <= coordinate && (left === -1 || center > centers[left]))
                        left = index;
                    if (center >= coordinate && (right === -1 || center < centers[right]))
                        right = index;
                });
            }
            let anchorOffset = 0;
            if (left === -1) {
                if (right !== -1)
                    anchorOffset = offsets[right];
            }
            else if (right === -1) {
                anchorOffset = offsets[left];
            }
            else if (left === right || centers[left] === centers[right]) {
                anchorOffset = offsets[left];
            }
            else {
                const progress = (coordinate - centers[left]) / (centers[right] - centers[left]);
                anchorOffset = offsets[left] + (offsets[right] - offsets[left]) * progress;
            }
            screen.magnificationGrowth = extra;
            screen.magnificationStart = offsets[0] - anchorOffset - size * (scales[0] - 1) / 2;
            const duration = animated && !following
                ? Math.round(this._settings.get_int('dock-hover-duration') * 160 / 180) : 0;
            this._updateMagnificationBackground(screen, duration);
            buttons.forEach((button, index) => {
                const shift = offsets[index] - anchorOffset;
                const icon = button.icon?.icon ?? button.get_child();
                button.magnificationScale = scales[index];
                if (!button.dockLaunchAnimating)
                    icon.ease({ scale_x: scales[index], scale_y: scales[index],
                        duration, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
                button.ease({ translation_x: axis === 0 ? shift : 0, translation_y: axis === 1 ? shift : 0,
                    duration, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
                if (button.hover || button.has_key_focus())
                    button.updateDockTooltip?.();
            });
        }
        _updateMagnificationBackground(screen, duration = 0) {
            const background = screen.magnificationBackground;
            if (!background || screen.disposed)
                return;
            const [x, y] = screen.dockContainer.get_transformed_position();
            const [width, height] = screen.dockContainer.get_transformed_size();
            const padding = screen.magnificationPadding ?? 0;
            const growth = screen.magnificationGrowth ?? 0;
            const start = screen.magnificationStart ?? 0;
            const horizontal = screen.position === 0;
            const baseWidth = width - (horizontal ? padding * 6 : padding);
            const baseHeight = height - (horizontal ? padding : padding * 6);
            if (baseWidth <= 0 || baseHeight <= 0)
                return;
            const geometry = {
                x: x + (horizontal ? padding * 3 + start : screen.position === 2 ? padding : 0),
                y: y + (horizontal ? padding : padding * 3 + start),
                width: baseWidth + (horizontal ? growth : 0),
                height: baseHeight + (horizontal ? 0 : growth),
            };
            if (screen.magnificationBackgroundGeometry && Object.entries(geometry).every(([key, value]) => screen.magnificationBackgroundGeometry[key] === value))
                return;
            screen.magnificationBackgroundGeometry = geometry;
            background.ease({
                ...geometry,
                duration,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            });
        }
        _animateDockLaunch(button, screen) {
            if (!this._settings.get_boolean('dock-launch-animation'))
                return;
            const icon = button.icon?.icon ?? button.get_child();
            const motion = St.Settings.get();
            const reduced = 'ReducedMotion' in St &&
                (motion.reduced_motion ?? motion.reducedMotion) === St.ReducedMotion.REDUCE;
            if (!motion.enable_animations || reduced) {
                button.dockLaunchAnimating = false;
                icon.ease({
                    scale_x: 1,
                    scale_y: 1,
                    translation_y: 0,
                    duration: 0,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                });
                button._dockHoverAnimationUpdate?.(true);
                if (screen)
                    this._updateDockMagnification(screen);
                return;
            }
            if (button.dockLaunchAnimating)
                return;
            button.dockLaunchAnimating = true;
            icon.remove_all_transitions();
            const duration = this._settings.get_int('dock-launch-duration');
            const liftDuration = Math.round(duration * 100 / 520);
            const strength = this._settings.get_int('dock-launch-strength') / 100;
            icon.ease({
                scale_x: 0.82 + 0.18 * (1 - strength),
                scale_y: 0.72 + 0.28 * (1 - strength),
                translation_y: -12 * strength,
                duration: liftDuration,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => {
                    if (button.destroyed)
                        return;
                    icon.ease({
                        scale_x: 1,
                        scale_y: 1,
                        translation_y: 0,
                        duration: duration - liftDuration,
                        mode: Clutter.AnimationMode.EASE_OUT_BOUNCE,
                        onComplete: () => {
                            button.dockLaunchAnimating = false;
                            button._dockHoverAnimationUpdate?.(true);
                            if (screen)
                                this._updateDockMagnification(screen);
                        },
                    });
                },
            });
        }
    };
}
//# sourceMappingURL=dockAppearance.js.map