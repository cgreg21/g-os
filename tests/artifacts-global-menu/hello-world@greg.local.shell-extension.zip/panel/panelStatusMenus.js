export class SoundStatusMenu {
    constructor(menu, icon, { control, St, Slider, PopupMenu, openSettings }) {
        this.menu = menu;
        this.icon = icon;
        this.control = control;
        this.PopupMenu = PopupMenu;
        this.streamSignals = [];
        this.controlSignals = [];
        const row = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
        this.muteIcon = new St.Icon({ icon_name: 'audio-volume-high-symbolic', icon_size: 20 });
        this.muteButton = new St.Button({ child: this.muteIcon, can_focus: true, reactive: true, track_hover: true,
            style_class: 'macos-sound-mute', accessible_name: 'Couper le son' });
        this.muteButton.connect('clicked', () => this.toggleMute());
        this.slider = new Slider.Slider(0);
        this.slider.width = 200;
        this.slider.accessible_name = 'Volume de sortie';
        this.sliderSignal = this.slider.connect('notify::value', () => this.changeVolume());
        row.add_child(this.muteButton);
        row.add_child(this.slider);
        menu.addMenuItem(row);
        this.percentage = new PopupMenu.PopupMenuItem('Volume indisponible', { reactive: false, can_focus: false });
        this.percentage.add_style_class_name('macos-status-info');
        menu.addMenuItem(this.percentage);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Sortie audio'));
        this.devices = new PopupMenu.PopupMenuSection();
        menu.addMenuItem(this.devices);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        menu.addAction('Parametres du son', openSettings);
        this.openSignal = menu.connect('open-state-changed', (actor, open) => {
            if (open)
                this.syncOutput();
        });
        for (const signal of ['state-changed', 'default-sink-changed', 'stream-added', 'stream-removed', 'output-added', 'output-removed'])
            this.controlSignals.push(control.connect(signal, () => this.syncOutput()));
        this.syncOutput();
    }
    syncOutput() {
        const stream = this.control.get_default_sink();
        if (stream !== this.stream) {
            for (const id of this.streamSignals)
                this.stream?.disconnect(id);
            this.streamSignals = [];
            this.stream = stream;
            if (stream) {
                for (const signal of ['notify::volume', 'notify::is-muted'])
                    this.streamSignals.push(stream.connect(signal, () => this.refresh()));
            }
        }
        this.refresh();
        this.refreshDevices();
    }
    refresh() {
        const maximum = this.control.get_vol_max_norm() || 1;
        const level = this.stream ? Math.max(0, this.stream.volume / maximum) : 0;
        const volume = Math.min(1, level);
        const muted = !this.stream || this.stream.is_muted || volume === 0;
        this.syncing = true;
        this.slider.value = volume;
        this.syncing = false;
        this.slider.reactive = Boolean(this.stream);
        this.slider.can_focus = Boolean(this.stream);
        this.muteButton.reactive = Boolean(this.stream);
        this.muteButton.can_focus = Boolean(this.stream);
        if (this.stream)
            this.muteButton.remove_style_pseudo_class('insensitive');
        else
            this.muteButton.add_style_pseudo_class('insensitive');
        const icon = muted ? 'audio-volume-muted-symbolic' : volume < 0.34 ? 'audio-volume-low-symbolic'
            : volume < 0.67 ? 'audio-volume-medium-symbolic' : 'audio-volume-high-symbolic';
        this.icon.icon_name = icon;
        this.muteIcon.icon_name = icon;
        this.muteButton.accessible_name = muted ? 'Activer le son' : 'Couper le son';
        this.percentage.label.text = this.stream ? `${Math.round(level * 100)} %${muted ? ' - Muet' : ''}` : 'Aucune sortie audio';
    }
    changeVolume() {
        if (this.syncing || !this.stream)
            return;
        const volume = Math.round(Math.max(0, Math.min(1, this.slider.value)) * this.control.get_vol_max_norm());
        this.stream.set_volume(volume);
        this.stream.push_volume();
        this.stream.change_is_muted(volume === 0);
        this.refresh();
    }
    toggleMute() {
        if (!this.stream)
            return;
        const muted = this.stream.is_muted || this.stream.volume === 0;
        if (muted && this.stream.volume === 0) {
            this.stream.set_volume(Math.round(this.control.get_vol_max_norm() * 0.25));
            this.stream.push_volume();
        }
        this.stream.change_is_muted(!muted);
        this.refresh();
    }
    refreshDevices() {
        this.devices.removeAll();
        const streams = this.control.get_sinks();
        let count = 0;
        for (const stream of streams) {
            const device = this.control.lookup_device_from_stream(stream);
            if (!device)
                continue;
            const label = stream.get_description() || stream.get_name() || 'Sortie audio';
            const item = this.devices.addAction(label, () => this.control.change_output(device.get_id()));
            count++;
            item.setOrnament(stream === this.stream ? this.PopupMenu.Ornament.DOT : this.PopupMenu.Ornament.NONE);
        }
        if (count === 0) {
            const item = this.devices.addAction('Aucune sortie audio disponible', () => { });
            item.setSensitive(false);
        }
    }
    destroy() {
        this.menu.disconnect(this.openSignal);
        this.slider.disconnect(this.sliderSignal);
        for (const id of this.streamSignals)
            this.stream?.disconnect(id);
        for (const id of this.controlSignals)
            this.control.disconnect(id);
        this.streamSignals = [];
        this.controlSignals = [];
    }
}
class NativeMenuContent {
    constructor(menu, holder, { onOpen = () => { }, onClose = () => { } } = {}) {
        this.menu = menu;
        this.holder = holder;
        this.onOpen = onOpen;
        this.onClose = onClose;
    }
    mount(nativeMenu, notifyOpen = true) {
        this.restore();
        const actor = nativeMenu?.box;
        const parent = actor?.get_parent();
        if (!parent)
            return false;
        const index = parent.get_children().indexOf(actor);
        this.saved = { actor, parent, index, nativeMenu, notifyOpen, wasOpen: Boolean(nativeMenu.isOpen) };
        parent.remove_child(actor);
        actor.add_style_class_name('macos-status-native-content');
        this.holder.add_child(actor);
        actor.show();
        this.activateSignal = nativeMenu.connect('activate', () => this.menu.close());
        nativeMenu.isOpen = true;
        if (notifyOpen)
            this.onOpen();
        return true;
    }
    restore() {
        if (!this.saved)
            return;
        const { actor, parent, index, nativeMenu, notifyOpen, wasOpen } = this.saved;
        nativeMenu.disconnect(this.activateSignal);
        actor.get_parent()?.remove_child(actor);
        actor.remove_style_class_name('macos-status-native-content');
        parent.insert_child_at_index(actor, index);
        this.saved = null;
        nativeMenu.isOpen = wasOpen;
        if (notifyOpen)
            this.onClose();
    }
}
export class RadioStatusMenu {
    constructor(menu, icon, { toggle, title, St, PopupMenu, openSettings }) {
        this.menu = menu;
        this.icon = icon;
        this.toggle = toggle;
        this.header = new PopupMenu.PopupSwitchMenuItem(title, Boolean(toggle?.checked));
        this.header.setSensitive(Boolean(toggle) && toggle.visible !== false && toggle.reactive !== false);
        this.header.connect('toggled', (actor, checked) => {
            if (toggle && checked !== Boolean(toggle.checked))
                toggle.emit('clicked', 1);
        });
        menu.addMenuItem(this.header);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const item = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
        this.holder = new St.BoxLayout({ vertical: true });
        item.add_child(this.holder);
        menu.addMenuItem(item);
        this.content = new NativeMenuContent(menu, this.holder, {
            onOpen: () => {
                toggle?._startScanning?.();
                toggle?._reorderDeviceItems?.();
            },
            onClose: () => toggle?._stopScanning?.(),
        });
        if (!toggle) {
            const unavailable = new PopupMenu.PopupMenuItem('Service indisponible', { reactive: false, can_focus: false });
            menu.addMenuItem(unavailable);
        }
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.settingsItem = menu.addAction(`Parametres ${title}`, openSettings);
        this.signals = [];
        if (toggle) {
            for (const signal of ['notify::checked', 'notify::icon-name', 'notify::visible', 'notify::reactive'])
                this.signals.push(toggle.connect(signal, () => this.refresh()));
        }
        this.openSignal = menu.connect('open-state-changed', (actor, open) => {
            if (open) {
                const mounted = this.content.mount(toggle?.menu, Boolean(toggle) && toggle.visible !== false);
                this.settingsItem.visible = !mounted;
                this.refresh();
            }
            else
                this.content.restore();
        });
        this.refresh();
    }
    refresh() {
        this.header.setToggleState(Boolean(this.toggle?.checked));
        this.header.setSensitive(Boolean(this.toggle) && this.toggle.visible !== false && this.toggle.reactive !== false);
        if (this.toggle?.icon_name)
            this.icon.icon_name = this.toggle.icon_name;
    }
    destroy() {
        this.content.restore();
        this.menu.disconnect(this.openSignal);
        for (const id of this.signals)
            this.toggle.disconnect(id);
    }
}
export class BatteryStatusMenu {
    constructor(menu, icon, { powerToggle, profiles, St, PopupMenu, openSettings }) {
        this.menu = menu;
        this.icon = icon;
        this.powerToggle = powerToggle;
        this.proxy = powerToggle?._proxy;
        this.profiles = profiles;
        this.percentage = new PopupMenu.PopupMenuItem('', { reactive: false, can_focus: false });
        this.state = new PopupMenu.PopupMenuItem('', { reactive: false, can_focus: false });
        this.percentage.add_style_class_name('macos-status-info');
        this.state.add_style_class_name('macos-status-info');
        menu.addMenuItem(this.percentage);
        menu.addMenuItem(this.state);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Mode d\u2019alimentation'));
        const item = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
        this.holder = new St.BoxLayout({ vertical: true });
        item.add_child(this.holder);
        menu.addMenuItem(item);
        this.content = new NativeMenuContent(menu, this.holder);
        if (!profiles) {
            const unavailable = new PopupMenu.PopupMenuItem('Profils indisponibles', { reactive: false, can_focus: false });
            menu.addMenuItem(unavailable);
        }
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.settingsItem = menu.addAction('Parametres d\u2019alimentation', openSettings);
        this.proxySignal = this.proxy?.connect('g-properties-changed', () => this.refresh());
        this.openSignal = menu.connect('open-state-changed', (actor, open) => {
            if (open) {
                this.settingsItem.visible = !this.content.mount(profiles?.menu);
                this.refresh();
            }
            else
                this.content.restore();
        });
        this.refresh();
    }
    refresh() {
        const proxy = this.proxy;
        if (!proxy?.IsPresent) {
            this.percentage.label.text = 'Aucune batterie';
            this.state.label.text = 'Alimentation secteur';
            return;
        }
        this.percentage.label.text = `Batterie : ${Math.round(proxy.Percentage)} %`;
        const states = ['Etat inconnu', 'En charge', 'Sur batterie', 'Batterie vide', 'Charge complete', 'Charge en attente', 'Decharge en attente'];
        const seconds = proxy.State === 1 ? proxy.TimeToFull : proxy.State === 2 ? proxy.TimeToEmpty : 0;
        const minutes = Math.max(0, Math.round(Number(seconds) / 60));
        const time = minutes > 0 ? ` - ${Math.floor(minutes / 60)} h ${minutes % 60} min` : '';
        this.state.label.text = `${states[proxy.State] ?? states[0]}${time}`;
        if (proxy.IconName)
            this.icon.icon_name = proxy.IconName;
    }
    destroy() {
        this.content.restore();
        this.menu.disconnect(this.openSignal);
        if (this.proxySignal)
            this.proxy.disconnect(this.proxySignal);
    }
}
//# sourceMappingURL=panelStatusMenus.js.map