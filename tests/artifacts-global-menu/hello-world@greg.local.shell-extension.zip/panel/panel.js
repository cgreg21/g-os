import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as SystemActions from 'resource:///org/gnome/shell/misc/systemActions.js';
import * as Volume from 'resource:///org/gnome/shell/ui/status/volume.js';
import * as Slider from 'resource:///org/gnome/shell/ui/slider.js';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import { GtkGlobalMenu } from './globalMenu.js';
import { SoundStatusMenu, RadioStatusMenu, BatteryStatusMenu } from './panelStatusMenus.js';
export function withPanel(Base) {
    return class extends Base {
        _populatePanelMenu(button) {
            button.menu.actor.add_style_class_name('macos-popup');
            button.menu.addAction('Vue d’ensemble', () => Main.overview.show());
            button.menu.addAction('Applications', () => Main.overview.showApps());
            button.menu.addAction('Rechercher', () => Main.overview.focusSearch());
            const desktop = button.menu.addAction('Afficher le bureau', () => this._toggleDesktop());
            button.menu.addAction('Préférences', () => this.openPreferences());
            const settings = button.menu.addAction('Paramètres système', () => {
                const app = this._appSystem.lookup_app('org.gnome.Settings.desktop');
                if (app) {
                    Main.overview.hide();
                    app.activate();
                }
            });
            const actions = SystemActions.getDefault();
            const lock = button.menu.addAction('Verrouiller la session', () => {
                if (actions.canLockScreen)
                    actions.activateLockScreen();
            });
            const quit = button.menu.addAction('Quitter l’application', () => {
                quit.targetApp?.request_quit();
            });
            const updateQuit = () => {
                const window = global.display.focus_window;
                const app = window ? Shell.WindowTracker.get_default().get_window_app(window) : null;
                quit.targetApp = typeof app?.request_quit === 'function' ? app : null;
                quit.label.text = quit.targetApp ? `Quitter ${quit.targetApp.get_name()}` : 'Quitter l’application';
                quit.setSensitive(Boolean(quit.targetApp));
            };
            updateQuit();
            const updateLock = () => lock.setSensitive(actions.canLockScreen);
            updateLock();
            const lockSignal = actions.connect('notify::can-lock-screen', updateLock);
            button.connect('destroy', () => actions.disconnect(lockSignal));
            settings.setSensitive(Boolean(this._appSystem.lookup_app('org.gnome.Settings.desktop')));
            button.menu.connect('open-state-changed', (menu, open) => {
                if (open) {
                    updateQuit();
                    desktop.label.text = this._desktopActionName();
                    settings.setSensitive(Boolean(this._appSystem.lookup_app('org.gnome.Settings.desktop')));
                    updateLock();
                }
            });
        }
        _createPanel(screen) {
            const { monitor } = screen;
            screen.panel = new St.BoxLayout({
                name: 'panel',
                style_class: 'macos-secondary-panel',
                height: this._settings.get_int('panel-height'),
                reactive: true,
            });
            if (this._settings.get_boolean('panel-style'))
                screen.panel.add_style_class_name('macos-panel');
            screen.menuButton = monitor.index === Main.layoutManager.primaryIndex
                ? this._menu : new PanelMenu.Button(0.0, 'Applications');
            screen.menuButton.add_style_class_name('macos-panel-menu');
            if (screen.menuButton !== this._menu) {
                screen.menuIcon = new St.Icon({
                    icon_name: 'view-app-grid-symbolic',
                    style_class: 'system-status-icon',
                });
                screen.menuButton.add_child(screen.menuIcon);
                this._populatePanelMenu(screen.menuButton);
            }
            else
                screen.menuIcon = this._menuIcon;
            Main.panel.menuManager.addMenu(screen.menuButton.menu);
            screen.panel.add_child(screen.menuButton.container);
            screen.appLabel = monitor.index === Main.layoutManager.primaryIndex
                ? this._activeAppLabel : new St.Label({
                style_class: 'macos-active-app',
                y_align: Clutter.ActorAlign.CENTER,
                visible: this._settings.get_boolean('show-active-app'),
            });
            screen.appLabel.visible = this._settings.get_boolean('show-active-app');
            screen.panel.add_child(screen.appLabel);
            if (this._settings.get_boolean('global-menu-enabled')) {
                screen.globalMenuBox = new St.BoxLayout({style_class: 'macos-global-menu'});
                screen.panel.add_child(screen.globalMenuBox);
                screen.globalMenu = new GtkGlobalMenu(screen.globalMenuBox, {
                    Gio, GLib, St, Clutter, PopupMenu, menuManager: Main.panel.menuManager, uiGroup: Main.uiGroup,
                });
            }
            screen.transferLabel = monitor.index === Main.layoutManager.primaryIndex
                ? this._transferLabel : new St.Label({
                style_class: 'macos-transfer-total',
                y_align: Clutter.ActorAlign.CENTER,
                visible: false,
            });
            screen.panel.add_child(screen.transferLabel);
            screen.panel.add_child(new St.Widget({ x_expand: true }));
            screen.clock = new St.Label({ name: 'macos-panel-clock', y_align: Clutter.ActorAlign.CENTER,
                visible: this._settings.get_boolean('panel-show-clock') });
            screen.panel.add_child(screen.clock);
            screen.searchIcon = new St.Icon({ icon_name: 'system-search-symbolic', style_class: 'system-status-icon' });
            const search = new St.Button({
                style_class: 'panel-button',
                accessible_name: 'Rechercher',
                visible: this._settings.get_boolean('panel-show-search'),
                can_focus: true,
                child: screen.searchIcon,
            });
            search.connect('clicked', () => Main.overview.focusSearch());
            screen.panel.add_child(search);
            const preferences = new St.Button({
                style_class: 'panel-button',
                accessible_name: 'Préférences macOS Style',
                visible: this._settings.get_boolean('panel-show-preferences'),
                can_focus: true,
                child: screen.preferencesIcon = new St.Icon({
                    icon_name: 'preferences-system-symbolic', style_class: 'system-status-icon',
                }),
            });
            preferences.connect('clicked', () => this.openPreferences());
            screen.panel.add_child(preferences);
            screen.statusButtons = [];
            for (const [name, iconName, accessibleName] of [
                ['wifi', 'network-wireless-signal-excellent-symbolic', 'Réseau Wi-Fi'],
                ['bluetooth', 'bluetooth-active-symbolic', 'Bluetooth'],
                ['sound', 'audio-volume-high-symbolic', 'Son'],
                ['battery', 'battery-good-symbolic', 'Batterie'],
            ]) {
                const statusIcon = new St.Icon({ icon_name: iconName, style_class: 'system-status-icon' });
                const button = new St.Button({
                    style_class: 'panel-button macos-status-button',
                    accessible_name: accessibleName,
                    visible: this._settings.get_boolean(`panel-show-${name}`),
                    can_focus: true,
                    child: statusIcon,
                });
                button.statusKind = name;
                button.statusIcon = statusIcon;
                this._createStatusMenu(button);
                button.connect('clicked', () => {
                    if (!button.statusMenu.isOpen)
                        Main.panel.statusArea?.quickSettings?.menu?.close();
                    button.statusMenu.toggle();
                });
                screen.statusButtons.push(button);
                screen.panel.add_child(button);
            }
            screen.sessionButton = new PanelMenu.Button(0.0, 'Session');
            screen.sessionButton.add_style_class_name('macos-session-button');
            screen.sessionIcon = new St.Icon({
                icon_name: 'avatar-default-symbolic',
                style_class: 'system-status-icon',
            });
            screen.sessionButton.add_child(screen.sessionIcon);
            this._populateSessionMenu(screen.sessionButton);
            Main.panel.menuManager.addMenu(screen.sessionButton.menu);
            screen.panel.add_child(screen.sessionButton.container);
            this._applyPanelMetrics(screen);
            screen.panel.set_position(monitor.x, monitor.y);
            screen.panel.set_width(monitor.width);
            Main.layoutManager.addChrome(screen.panel, { affectsStruts: true, trackFullscreen: true });
        }
        _applyPanelMetrics(screen) {
            const height = this._settings.get_int('panel-height');
            const horizontalPadding = this._settings.get_int('panel-padding-horizontal');
            const verticalPadding = Math.min(this._settings.get_int('panel-padding-vertical'), Math.max(0, Math.floor((height - 22) / 2)));
            const contentHeight = height - verticalPadding * 2;
            const availableLabelWidth = Math.max(48, screen.monitor.width - 360 - horizontalPadding * 2);
            const baseFontSize = Math.max(10, Math.min(20, Math.floor(contentHeight * 0.56)));
            const labelLength = screen.appLabel.text?.length ?? 0;
            const estimatedLabelWidth = labelLength * baseFontSize * 0.56;
            const widthScale = estimatedLabelWidth > 0
                ? Math.min(1, availableLabelWidth / estimatedLabelWidth) : 1;
            screen.fontSize = Math.max(10, Math.floor(baseFontSize * widthScale));
            screen.iconSize = Math.max(16, screen.fontSize);
            screen.panel.set_style(`padding: ${verticalPadding}px ${horizontalPadding}px;`);
            screen.appLabel.clutter_text.ellipsize = Pango.EllipsizeMode.END;
            screen.appLabel.set_style(`font-size: ${screen.fontSize}px; max-width: ${availableLabelWidth}px;`);
            for (const label of [screen.clock, screen.transferLabel])
                label.set_style(`font-size: ${screen.fontSize}px;`);
            for (const icon of [screen.menuIcon, screen.searchIcon, screen.preferencesIcon,
                ...screen.statusButtons.map(button => button.statusIcon), screen.sessionIcon])
                icon.set_style(`icon-size: ${screen.iconSize}px;`);
        }
        _createStatusMenu(button) {
            const menu = new PopupMenu.PopupMenu(button, 0.5, St.Side.TOP);
            menu.actor.add_style_class_name('macos-popup');
            menu.actor.add_style_class_name(`macos-status-menu-${button.statusKind}`);
            Main.uiGroup.add_child(menu.actor);
            menu.actor.hide();
            Main.panel.menuManager.addMenu(menu);
            button.statusMenu = menu;
            const quick = Main.panel.statusArea?.quickSettings;
            const settings = panel => () => {
                const app = this._appSystem.lookup_app(`gnome-${panel}-panel.desktop`) ??
                    this._appSystem.lookup_app('org.gnome.Settings.desktop');
                app?.activate();
            };
            if (button.statusKind === 'sound') {
                button.statusController = new SoundStatusMenu(menu, button.statusIcon, {
                    control: Volume.getMixerControl(), St, Slider, PopupMenu, openSettings: settings('sound'),
                });
            }
            else if (['wifi', 'bluetooth'].includes(button.statusKind)) {
                const toggle = button.statusKind === 'wifi' ? quick?._network?._wirelessToggle
                    : quick?._bluetooth?.quickSettingsItems?.[0];
                button.statusController = new RadioStatusMenu(menu, button.statusIcon, { toggle,
                    title: button.statusKind === 'wifi' ? 'Wi-Fi' : 'Bluetooth', St, PopupMenu,
                    openSettings: settings(button.statusKind === 'wifi' ? 'wifi' : 'bluetooth') });
            }
            else {
                button.statusController = new BatteryStatusMenu(menu, button.statusIcon, {
                    powerToggle: quick?._system?._systemItem?.powerToggle ?? quick?._system?._systemItem?._powerToggle ??
                        quick?._system?.quickSettingsItems?.[0]?.powerToggle,
                    profiles: quick?._powerProfiles?._powerProfilesToggle, St, PopupMenu, openSettings: settings('power'),
                });
            }
            button.connect('popup-menu', () => {
                Main.panel.statusArea?.quickSettings?.menu?.close();
                menu.open();
            });
        }
        _openQuickSettings(button) {
            const menu = Main.panel.statusArea?.quickSettings?.menu;
            if (!menu)
                return;
            if (menu.isOpen) {
                menu.close();
                return;
            }
            menu.sourceActor = button;
            menu.open();
        }
        _populateSessionMenu(button) {
            const actions = SystemActions.getDefault();
            button.menu.actor.add_style_class_name('macos-popup');
            const addSystemAction = (label, available, activate) => {
                const item = button.menu.addAction(label, () => {
                    if (actions[available])
                        actions[activate]();
                });
                item.setSensitive(Boolean(actions[available]));
                return item;
            };
            const restart = addSystemAction('Redémarrer', 'canRestart', 'activateRestart');
            const powerOff = addSystemAction('Éteindre', 'canPowerOff', 'activatePowerOff');
            const logout = addSystemAction('Se déconnecter', 'canLogout', 'activateLogout');
            button.menu.addAction('Préférences macOS Style', () => this.openPreferences());
            const settings = button.menu.addAction('Paramètres système', () => {
                const app = this._appSystem.lookup_app('org.gnome.Settings.desktop');
                if (app) {
                    Main.overview.hide();
                    app.activate();
                }
            });
            const lock = addSystemAction('Verrouiller la session', 'canLockScreen', 'activateLockScreen');
            const suspend = addSystemAction('Suspendre', 'canSuspend', 'activateSuspend');
            const updateSensitivity = () => {
                for (const [item, capability] of [[restart, 'canRestart'], [powerOff, 'canPowerOff'],
                    [logout, 'canLogout'], [lock, 'canLockScreen'], [suspend, 'canSuspend']])
                    item.setSensitive(Boolean(actions[capability]));
                settings.setSensitive(Boolean(this._appSystem.lookup_app('org.gnome.Settings.desktop')));
            };
            updateSensitivity();
            button.menu.connect('open-state-changed', (menu, open) => {
                if (open)
                    updateSensitivity();
            });
        }
        _updateClocks() {
            const text = this._wallClock.clock;
            for (const screen of this._screens) {
                if (screen.clock)
                    screen.clock.text = text;
            }
        }
    };
}
//# sourceMappingURL=panel.js.map