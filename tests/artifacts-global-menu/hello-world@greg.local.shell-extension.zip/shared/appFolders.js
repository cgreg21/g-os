export function readAppFolders(settings) {
    try {
        const value = JSON.parse(settings.get_string?.('dock-app-folders') ?? '[]');
        if (!Array.isArray(value))
            return [];
        const ids = new Set();
        const applications = new Set();
        const folders = [];
        for (const folder of value) {
            if (!folder || typeof folder.id !== 'string' || !/^[a-zA-Z0-9_-]+$/.test(folder.id) ||
                typeof folder.name !== 'string' || !Array.isArray(folder.apps) || ids.has(folder.id))
                continue;
            ids.add(folder.id);
            const apps = [];
            for (const app of folder.apps) {
                if (typeof app !== 'string' || !app.endsWith('.desktop') || applications.has(app))
                    continue;
                applications.add(app);
                apps.push(app);
            }
            folders.push({
                id: folder.id,
                name: folder.name.trim() || 'Applications',
                apps,
                icon: typeof folder.icon === 'string' ? folder.icon : '',
                view: folder.view === 0 || folder.view === 1 ? folder.view : -1,
            });
        }
        return folders;
    }
    catch {
        return [];
    }
}
export function writeAppFolders(settings, folders) {
    if (!settings.is_writable('dock-app-folders'))
        return false;
    return settings.set_string('dock-app-folders', JSON.stringify(folders));
}
const FOLDER_SORT_CHOICES = ['Nom : A à Z', 'Nom : Z à A', 'Taille croissante', 'Taille décroissante',
    'Date : plus anciennes d’abord', 'Date : plus récentes d’abord'];
export const FOLDER_VIEW_OPTIONS = {
    pile: {
        'text-size': { default: 12, min: 8, max: 32, title: 'Taille du texte (px)' },
        'icon-size': { default: 48, min: 16, max: 96, title: 'Taille des icônes (px)' },
        'spacing': { default: 6, min: 0, max: 48, title: 'Espace entre les icônes (px)' },
        'max-files': { default: 9, min: 1, max: 100, title: 'Nombre maximal de fichiers', filesOnly: true },
        'sort-order': { default: 0, min: 0, max: 5, title: 'Tri', choices: FOLDER_SORT_CHOICES, filesOnly: true },
    },
    grille: {
        'text-size': { default: 10, min: 8, max: 32, title: 'Taille du texte (px)' },
        'icon-size': { default: 36, min: 16, max: 96, title: 'Taille des icônes (px)' },
        'horizontal-spacing': { default: 8, min: 0, max: 48, title: 'Espace horizontal (px)' },
        'vertical-spacing': { default: 8, min: 0, max: 48, title: 'Espace vertical (px)' },
        'columns': { default: 4, min: 1, max: 10, title: 'Nombre de colonnes' },
        'rows': { default: 6, min: 1, max: 12, title: 'Nombre de lignes', filesOnly: true },
        'sort-order': { default: 0, min: 0, max: 5, title: 'Tri', choices: FOLDER_SORT_CHOICES, filesOnly: true },
    },
};
export function folderViewOptions(settings, view, folderKey = null) {
    const stored = settings.get_value('dock-view-options').deep_unpack();
    const defaults = stored[view] ?? {};
    const overrides = folderKey ? stored[`${folderKey}:${view}`] ?? {} : {};
    return Object.fromEntries(Object.entries(FOLDER_VIEW_OPTIONS[view]).map(([key, spec]) => {
        const isValid = (value) => Number.isInteger(value) && value >= spec.min && value <= spec.max;
        let value = isValid(defaults[key]) ? defaults[key] : spec.default;
        if (isValid(overrides[key]))
            value = overrides[key];
        return [key, value];
    }));
}
//# sourceMappingURL=appFolders.js.map