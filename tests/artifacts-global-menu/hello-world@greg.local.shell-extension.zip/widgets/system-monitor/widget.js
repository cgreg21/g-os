export function create(context) {
    const { api, config } = context;
    const dock = context.target === 'dock';
    const view = api.card('Systeme', 'utilities-system-monitor-symbolic');
    const value = context.square && dock ? api.icon('utilities-system-monitor-symbolic', context.iconSize)
        : api.label('CPU ...', { style_class: 'macos-utility-value' });
    view.body.add_child(value);
    const memory = !dock ? api.label('RAM ...') : null;
    const load = !dock ? api.label('') : null;
    const uptime = !dock ? api.label('') : null;
    for (const label of [memory, load, uptime].filter(Boolean))
        view.body.add_child(label);
    let closed = false;
    let pending = false;
    let previous;
    const update = () => {
        if (pending || closed)
            return;
        pending = true;
        api.systemStats().then(stats => {
            if (closed)
                return;
            const total = previous ? stats.cpuTotal - previous.cpuTotal : 0;
            const idle = previous ? stats.cpuIdle - previous.cpuIdle : 0;
            const cpu = total > 0 ? Math.max(0, Math.min(100, Math.round((1 - idle / total) * 100))) : 0;
            previous = stats;
            if (!(context.square && dock))
                value.text = `CPU ${cpu} %`;
            if (memory) {
                memory.text = `RAM ${api.formatBytes(stats.memoryUsed)} / ${api.formatBytes(stats.memoryTotal)}`;
                load.text = `Charge ${stats.load.toFixed(2)}`;
                uptime.text = `Actif ${api.formatDuration(stats.uptime * 1000)}`;
            }
        }).catch(() => {
            if (!closed && !(context.square && dock))
                value.text = 'Systeme indisponible';
        }).finally(() => { pending = false; });
    };
    api.onCleanup(() => { closed = true; });
    api.every(config.interval * 1000, update);
    update();
    return { ...view, value, memory, update };
}
//# sourceMappingURL=widget.js.map