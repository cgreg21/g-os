import { requestFluxJson } from './fluxHttp.js';
import { renderFluxTemplate, resolveFluxValue } from './fluxLanguage.js';
export class FluxSession {
    program;
    environment;
    data = Object.create(null);
    status = Object.create(null);
    errors = Object.create(null);
    listeners = new Set();
    requests = new Map();
    timers = [];
    stopped = false;
    started = false;
    constructor(program, environment) {
        this.program = program;
        this.environment = environment;
    }
    subscribe(callback) {
        this.listeners.add(callback);
        return () => this.listeners.delete(callback);
    }
    start() {
        if (this.started || this.stopped)
            return;
        this.started = true;
        const { GLib } = this.environment;
        for (const [name, source] of Object.entries(this.program.sources)) {
            this.refresh(name);
            this.timers.push(GLib.timeout_add(GLib.PRIORITY_DEFAULT, source.refresh * 1000, () => {
                this.refresh(name);
                return GLib.SOURCE_CONTINUE;
            }));
        }
    }
    refresh(name) {
        const source = this.program.sources[name];
        if (this.stopped || !source || this.requests.has(name))
            return;
        this.status[name] = 'loading';
        this.errors[name] = '';
        this.notify();
        const request = requestFluxJson(this.environment, source.url, source.timeout);
        this.requests.set(name, request);
        request.promise.then(value => {
            if (this.stopped)
                return;
            this.data[name] = value;
            this.status[name] = 'ready';
        }).catch(error => {
            if (this.stopped)
                return;
            this.status[name] = 'error';
            const message = error instanceof Error ? error.message : '';
            this.errors[name] = /^(?:Reponse HTTP \d+|Reponse HTTP Flux trop volumineuse|Reponse HTTP Flux non JSON|Delai HTTP Flux depasse|URL HTTP Flux invalide)$/.test(message)
                ? message : 'Connexion HTTP impossible';
        }).finally(() => {
            this.requests.delete(name);
            if (!this.stopped)
                this.notify();
        });
    }
    notify() {
        for (const listener of this.listeners)
            listener();
    }
    destroy() {
        if (this.stopped)
            return;
        this.stopped = true;
        for (const timer of this.timers)
            this.environment.GLib.source_remove(timer);
        this.timers = [];
        for (const request of this.requests.values())
            request.cancel();
        this.requests.clear();
        this.listeners.clear();
    }
}
export function createFluxWidget(description, context, session) {
    const { api, target, square, config } = context;
    const view = api.card(description.name, description.icon || 'applications-utilities-symbolic');
    view.body.y_expand = true;
    const nodes = target === 'desktop' ? session.program.views.desktop
        : square ? session.program.views.square ?? session.program.views.dock ?? session.program.views.desktop
            : session.program.views.dock ?? session.program.views.desktop;
    let actorCount = 0;
    const values = (scope) => ({ data: session.data, status: session.status, error: session.errors,
        config, time: api.clockTimeText(), ...(scope.hasItem ? { item: scope.item } : {}) });
    const renderNode = (node, scope) => {
        if (node.type === 'button' && target !== 'desktop')
            return null;
        if (actorCount >= 128)
            return null;
        let actor;
        const children = [];
        if (node.type === 'text') {
            const style = node.style === 'title' ? 'macos-utility-title'
                : node.style === 'secondary' ? 'macos-desktop-widget-date' : '';
            actor = api.label('', { style_class: style });
        }
        else if (node.type === 'icon') {
            actor = api.icon(node.name, target === 'dock' ? context.iconSize : 24);
        }
        else if (node.type === 'button') {
            actor = api.button(node.name, () => renderFluxTemplate(node.text, values(scope)), () => session.refresh(node.source));
        }
        else if (node.type === 'repeat') {
            const list = api.list();
            actorCount++;
            return { actor: list.actor, node, scope, children, content: list.content };
        }
        else {
            actor = api.box({ vertical: node.type === 'column', style_class: 'macos-utility-body' });
            actorCount++;
            for (const child of node.children) {
                const binding = renderNode(child, scope);
                if (binding) {
                    children.push(binding);
                    actor.add_child(binding.actor);
                }
            }
            return { actor, node, scope, children };
        }
        actorCount++;
        return { actor, node, scope, children };
    };
    const bindings = [];
    for (const node of nodes) {
        const binding = renderNode(node, { hasItem: false });
        if (binding) {
            bindings.push(binding);
            view.body.add_child(binding.actor);
        }
    }
    const countBindings = (entries) => entries.reduce((sum, entry) => sum + 1 + countBindings(entry.children), 0);
    const updateNode = (binding) => {
        const { actor, node, scope } = binding;
        const current = values(scope);
        if (node.when)
            actor.visible = Boolean(resolveFluxValue(current, node.when));
        if (node.type === 'text')
            actor.text = renderFluxTemplate(node.text, current);
        if (node.type === 'button')
            actor.accessible_name = renderFluxTemplate(node.text, current);
        if (node.type === 'repeat') {
            const items = resolveFluxValue(current, node.items);
            if (items !== binding.items) {
                actorCount -= countBindings(binding.children);
                binding.content.destroy_all_children();
                binding.children = [];
                binding.items = items;
                if (Array.isArray(items)) {
                    for (const item of items.slice(0, 32)) {
                        for (const child of node.children) {
                            const next = renderNode(child, { hasItem: true, item });
                            if (next) {
                                binding.children.push(next);
                                binding.content.add_child(next.actor);
                            }
                        }
                    }
                }
            }
        }
        for (const child of binding.children)
            updateNode(child);
    };
    const update = () => {
        for (const binding of bindings)
            updateNode(binding);
    };
    const unsubscribe = session.subscribe(update);
    const usesClock = (entries) => entries.some(node => /\{\{\{?\s*[#^&]?\s*time\s*\}\}\}?/.test(node.text ?? '') || node.when === 'time' || usesClock(node.children ?? []));
    if (usesClock(nodes))
        api.watchClock(update);
    update();
    return { ...view, update, destroy: unsubscribe };
}
//# sourceMappingURL=fluxWidget.js.map