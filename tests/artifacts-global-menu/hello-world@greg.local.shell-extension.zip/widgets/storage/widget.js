export function create(context) {
    const { api, config } = context;
    const dock = context.target === 'dock';
    const view = api.card('Stockage', 'drive-harddisk-symbolic');
    const value = context.square && dock ? api.icon('drive-harddisk-symbolic', context.iconSize)
        : api.label('Disque ...', { style_class: 'macos-utility-value' });
    view.body.add_child(value);
    const detail = !dock ? api.label('') : null;
    if (detail) {
        view.body.add_child(detail);
        view.body.add_child(api.label(config.path));
    }
    let closed = false;
    let pending = false;
    const update = () => {
        if (pending || closed)
            return;
        pending = true;
        api.diskStats(config.path).then(stats => {
            if (closed)
                return;
            const used = Math.max(0, stats.total - stats.free);
            const percent = stats.total > 0 ? Math.min(100, Math.round(used / stats.total * 100)) : 0;
            if (!(context.square && dock))
                value.text = `${percent} % utilise`;
            if (detail)
                detail.text = `${api.formatBytes(stats.free)} libres / ${api.formatBytes(stats.total)}`;
        }).catch(() => {
            if (!closed && !(context.square && dock))
                value.text = 'Disque indisponible';
        }).finally(() => { pending = false; });
    };
    if (!dock)
        view.body.add_child(api.button('view-refresh-symbolic', 'Actualiser le stockage', update));
    api.onCleanup(() => { closed = true; });
    api.every(config.interval * 1000, update);
    update();
    return { ...view, value, detail, update };
}
//# sourceMappingURL=widget.js.map