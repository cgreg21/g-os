import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
export function withDockActivity(Base) {
    return class extends Base {
        _watchNotificationSource(source) {
            if (!this._notificationSources.has(source)) {
                const id = source.connect('notify::count', () => this._updateNotificationCounts());
                this._notificationSources.set(source, id);
            }
            this._updateNotificationCounts();
        }
        _startLauncherTracking() {
            this._dbusSubscriptions = [
                Gio.DBus.session.signal_subscribe(null, 'com.canonical.Unity.LauncherEntry', 'Update', null, null, Gio.DBusSignalFlags.NONE, (connection, sender, path, iface, signal, parameters) => this._onLauncherUpdate(sender, parameters)),
                Gio.DBus.session.signal_subscribe('org.freedesktop.DBus', 'org.freedesktop.DBus', 'NameOwnerChanged', '/org/freedesktop/DBus', null, Gio.DBusSignalFlags.NONE, (connection, sender, path, iface, signal, parameters) => {
                    const [name, previous, current] = parameters.deep_unpack();
                    if (name.startsWith(':') && previous && !current && this._launcherEntries.delete(name))
                        this._updateTransferIndicators();
                }),
            ];
            this._unityOwner = Gio.bus_own_name_on_connection(Gio.DBus.session, 'com.canonical.Unity', Gio.BusNameOwnerFlags.NONE, null, null);
        }
        _onLauncherUpdate(sender, parameters) {
            if (parameters.get_type_string() !== '(sa{sv})')
                return;
            const [appUri, properties] = parameters.deep_unpack();
            let appId;
            try {
                const uri = GLib.Uri.parse(appUri, GLib.UriFlags.NONE);
                if (uri.get_scheme() !== 'application')
                    return;
                appId = uri.get_host();
            }
            catch {
                return;
            }
            if (!appId?.endsWith('.desktop'))
                return;
            const progress = properties.progress?.unpack();
            const visible = properties['progress-visible']?.unpack();
            if (typeof visible !== 'boolean' && !(typeof progress === 'number' && Number.isFinite(progress)))
                return;
            let entries = this._launcherEntries.get(sender);
            if (!entries) {
                entries = new Map();
                this._launcherEntries.set(sender, entries);
            }
            const entry = entries.get(appId) ?? { progress: 0, visible: false };
            if (typeof progress === 'number' && Number.isFinite(progress))
                entry.progress = Math.max(0, Math.min(1, progress));
            if (typeof visible === 'boolean')
                entry.visible = visible;
            entry.revision = ++this._activityRevision;
            entries.set(appId, entry);
            this._updateTransferIndicators();
        }
        _updateTransferIndicators() {
            const active = new Map();
            for (const entries of this._launcherEntries.values()) {
                for (const [appId, entry] of entries) {
                    if (entry.visible && (!active.has(appId) || entry.revision > active.get(appId).revision))
                        active.set(appId, entry);
                }
            }
            this._activeTransfers = active;
            const totalText = active.size === 1
                ? `${Math.round(active.values().next().value.progress * 100)} %`
                : `${active.size} applis`;
            for (const label of [this._transferLabel, ...this._screens.map(screen => screen.transferLabel)]) {
                if (!label)
                    continue;
                label.text = totalText;
                label.visible = active.size > 0;
                label.accessible_name = `${active.size} applications signalent une progression`;
            }
            for (const screen of this._screens) {
                for (const button of screen.appButtons ?? []) {
                    const entry = active.get(button.app.get_id());
                    button.progressBar.visible = Boolean(entry);
                    button.progressFill.scale_x = entry?.progress ?? 0;
                    button.progressBar.accessible_name = entry
                        ? `Progression : ${Math.round(entry.progress * 100)} pour cent` : '';
                    this._positionTransferProgress(button);
                }
            }
            this._updateNotificationCounts();
            for (const screen of this._screens) {
                for (const button of screen.appButtons ?? []) {
                    if (button.hover || button.has_key_focus())
                        button.updateDockTooltip?.();
                }
            }
        }
        _unwatchNotificationSource(source) {
            const id = this._notificationSources.get(source);
            if (id !== undefined) {
                source.disconnect(id);
                this._notificationSources.delete(source);
            }
        }
        _updateNotificationCounts() {
            const counts = new Map();
            for (const source of this._notificationSources.keys()) {
                const count = source.count;
                const appId = source.app?.get_id() ?? source.policy?.id;
                if (appId && appId !== 'generic') {
                    const id = appId.endsWith('.desktop') ? appId : `${appId}.desktop`;
                    counts.set(id, (counts.get(id) ?? 0) + count);
                }
            }
            for (const screen of this._screens) {
                for (const button of screen.appButtons ?? []) {
                    const count = counts.get(button.app.get_id()) ?? 0;
                    button.notificationBadge.text = count > 99 ? '99+' : String(count);
                    button.notificationBadge.visible = count > 0;
                    button.accessible_name = count > 0
                        ? `${this._appDescription(button.app, screen)}, ${count} notifications`
                        : this._appDescription(button.app, screen);
                }
            }
        }
        _syncWorkspaceSignals(workspace) {
            if (this._observedWorkspace === workspace)
                return;
            if (this._observedWorkspace) {
                for (const id of this._workspaceSignals)
                    this._observedWorkspace.disconnect(id);
            }
            this._observedWorkspace = workspace;
            this._workspaceSignals = [];
            if (workspace) {
                for (const signal of ['window-added', 'window-removed']) {
                    this._workspaceSignals.push(workspace.connect(signal, () => {
                        this._queueDockRebuild();
                    }));
                }
            }
        }
        _syncRunningAppSignals(apps) {
            const active = new Set(apps);
            for (const [app, id] of this._runningAppSignals) {
                if (!active.has(app)) {
                    app.disconnect(id);
                    this._runningAppSignals.delete(app);
                }
            }
            for (const app of apps) {
                if (!this._runningAppSignals.has(app)) {
                    const id = app.connect('windows-changed', () => this._rebuildDock());
                    this._runningAppSignals.set(app, id);
                }
            }
        }
        _trackAttentionWindow(window) {
            if (!window || window.skip_taskbar || window.has_focus() ||
                (!window.demands_attention && !window.urgent))
                return;
            const app = Shell.WindowTracker.get_default().get_window_app(window);
            if (!app)
                return;
            if (!this._attentionWindows.has(window)) {
                const sync = () => {
                    if (window.has_focus() || (!window.demands_attention && !window.urgent))
                        this._forgetAttentionWindow(window);
                };
                const ids = [
                    window.connect('notify::demands-attention', sync),
                    window.connect('notify::urgent', sync),
                    window.connect('focus', () => this._forgetAttentionWindow(window)),
                    window.connect('unmanaged', () => this._forgetAttentionWindow(window)),
                ];
                this._attentionWindows.set(window, { app, ids });
            }
            this._updateAttentionIndicators();
        }
        _forgetAttentionWindow(window) {
            const entry = this._attentionWindows.get(window);
            if (!entry)
                return;
            for (const id of entry.ids)
                window.disconnect(id);
            this._attentionWindows.delete(window);
            this._updateAttentionIndicators();
        }
        _appNeedsAttention(app) {
            return [...this._attentionWindows.values()].some(entry => entry.app === app);
        }
        _updateAttentionIndicators() {
            for (const screen of this._screens) {
                for (const button of screen.appButtons ?? []) {
                    if (this._appNeedsAttention(button.app))
                        button.add_style_pseudo_class('needs-attention');
                    else
                        button.remove_style_pseudo_class('needs-attention');
                }
            }
            this._updateNotificationCounts();
        }
        _windowsForDock(app, screen) {
            const workspace = this._settings.get_boolean('dock-current-workspace')
                ? global.workspace_manager.get_active_workspace() : null;
            return app.get_windows().filter(window => !window.skip_taskbar &&
                (!workspace || window.located_on_workspace(workspace)));
        }
        _appDescription(app, screen) {
            const states = [];
            if (app.state === Shell.AppState.STARTING)
                states.push('démarrage en cours');
            if (this._appNeedsAttention(app))
                states.push('demande votre attention');
            if (screen) {
                const count = this._windowsForDock(app, screen).length;
                if (count > 1)
                    states.push(`${count} fenêtres`);
            }
            const transfer = this._activeTransfers.get(app.get_id());
            if (transfer)
                states.push(`progression ${Math.round(transfer.progress * 100)} %`);
            return states.length ? `${app.get_name()} : ${states.join(', ')}` : app.get_name();
        }
        _queueDockRebuild() {
            if (this._dockRebuildSource)
                return;
            this._dockRebuildSource = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._dockRebuildSource = 0;
                this._rebuildDock();
                return GLib.SOURCE_REMOVE;
            });
        }
        _finishDockMenu(screen) {
            if (screen.rebuildPending && !screen.disposed)
                this._queueDockRebuild();
        }
        _captureDockFocus() {
            const actor = global.stage.get_key_focus();
            if (!actor)
                return null;
            for (const screen of this._screens) {
                if (!screen.dock?.contains(actor))
                    continue;
                const buttons = screen.dock.get_children().filter(button => button.dockFocusKey);
                const index = buttons.findIndex(button => button === actor || button.contains(actor));
                if (index >= 0)
                    return { actor, monitor: screen.monitor.index, key: buttons[index].dockFocusKey, index };
            }
            return null;
        }
        _restoreDockFocus(focus) {
            if (!focus)
                return;
            const screen = this._screens.find(candidate => candidate.monitor.index === focus.monitor && candidate.dock);
            if (!screen || screen.disposed || screen.monitor.inFullscreen)
                return;
            const current = global.stage.get_key_focus();
            if (current && current !== focus.actor && !screen.dockContainer.contains(current))
                return;
            const buttons = screen.dock.get_children().filter(button => button.dockFocusKey);
            const target = buttons.find(button => button.dockFocusKey === focus.key) ??
                buttons[Math.min(focus.index, buttons.length - 1)];
            if (target) {
                this._revealDock(screen);
                target.grab_key_focus();
            }
        }
        _handleAppStateChanged(app) {
            if (!app || app.state === Shell.AppState.STOPPED || !this._favorites.isFavorite(app.get_id())) {
                this._rebuildDock();
                return;
            }
            const buttons = this._screens.flatMap(screen => (screen.appButtons ?? [])
                .filter(button => button.app === app).map(button => [screen, button]));
            if (buttons.length === 0) {
                this._rebuildDock();
                return;
            }
            const starting = app.state === Shell.AppState.STARTING;
            for (const [screen, button] of buttons) {
                if (starting)
                    button.add_style_pseudo_class('starting');
                else
                    button.remove_style_pseudo_class('starting');
                button.accessible_name = this._appDescription(app, screen);
                if (button.hover || button.has_key_focus())
                    button.updateDockTooltip?.();
            }
            this._updateNotificationCounts();
        }
    };
}
//# sourceMappingURL=dockActivity.js.map