import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as SystemActions from 'resource:///org/gnome/shell/misc/systemActions.js';
import * as Volume from 'resource:///org/gnome/shell/ui/status/volume.js';
import * as Slider from 'resource:///org/gnome/shell/ui/slider.js';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import { SoundStatusMenu, RadioStatusMenu, BatteryStatusMenu, createPowerDeviceClient, alignMenuRows } from './panelStatusMenus.js';
import { GtkGlobalMenu } from './globalMenu.js';
export function withPanel(Base) {
    return class extends Base {
        _applyNotificationPosition() {
            const tray = Main.messageTray;
            const banner = tray._bannerBin;
            if (!banner)
                return;
            if (!this._notificationPosition) {
                const parent = banner.get_parent();
                if (!parent)
                    return;
                const index = parent.get_children().indexOf(banner);
                const container = new St.Widget({ layout_manager: new Clutter.BinLayout(),
                    x_expand: true, y_expand: true, reactive: false });
                parent.remove_child(banner);
                container.add_child(banner);
                parent.insert_child_at_index(container, index);
                this._notificationPosition = { banner, parent, index, container };
            }
            const start = Clutter.ActorAlign.START;
            const center = Clutter.ActorAlign.CENTER;
            const end = Clutter.ActorAlign.END;
            const positions = [[center, start], [start, start], [end, start],
                [start, center], [center, center], [end, center],
                [start, end], [center, end], [end, end]];
            const [x, y] = positions[this._settings.get_int('notification-position')] ?? positions[0];
            this._notificationPosition.container.x_align = x;
            this._notificationPosition.container.y_align = y;
        }
        _restoreNotificationPosition() {
            const state = this._notificationPosition;
            if (!state)
                return;
            state.container.remove_child(state.banner);
            state.parent.remove_child(state.container);
            state.parent.insert_child_at_index(state.banner, state.index);
            state.container.destroy();
            this._notificationPosition = null;
        }
        _populateNotificationMenu(menu) {
            menu.removeAll();
            const notifications = Main.messageTray.getSources().flatMap(source => source.notifications ?? []);
            if (!notifications.length) {
                menu.addAction('Aucune notification', () => { }).setSensitive(false);
                return;
            }
            for (const notification of notifications) {
                const title = notification.title || notification.source?.title || 'Notification';
                const item = menu.addAction(notification.body ? `${title}\n${notification.body}` : title, () => {
                    if (Main.messageTray.getSources().some(source => source.notifications?.includes(notification)))
                        notification.activate();
                });
                if (item.label.clutter_text) {
                    item.label.clutter_text.line_wrap = true;
                    item.label.set_style('max-width: 360px;');
                }
            }
            menu.addAction('Tout effacer', () => {
                for (const source of Main.messageTray.getSources()) {
                    for (const notification of [...(source.notifications ?? [])])
                        notification.destroy();
                }
            });
        }
        _updatePanelNotificationVisibility(screen) {
            screen.notificationButton.container.visible = this._settings.get_boolean('panel-show-notifications') &&
                Main.messageTray.getSources().some(source => source.notifications?.length > 0);
            if (!screen.notificationButton.container.visible)
                screen.notificationMenu.close();
        }
        _updatePanelNotifications() {
            for (const screen of this._screens ?? []) {
                if (!screen.notificationButton)
                    continue;
                this._updatePanelNotificationVisibility(screen);
                if (screen.notificationMenu?.isOpen)
                    this._populateNotificationMenu(screen.notificationMenu);
            }
        }
        _createNotificationButton(screen) {
            const button = new PanelMenu.Button(0.0, 'Notifications');
            const menu = button.menu;
            screen.notificationButton = button;
            screen.notificationMenu = menu;
            screen.notificationIcon = new St.Icon({ icon_name: 'preferences-system-notifications-symbolic',
                style_class: 'system-status-icon' });
            button.add_child(screen.notificationIcon);
            this._updatePanelNotificationVisibility(screen);
            menu.actor.add_style_class_name('g-os-popup');
            if (menu._boxPointer?.bin) {
                const scroll = new St.ScrollView({ vscrollbar_policy: St.PolicyType.AUTOMATIC,
                    hscrollbar_policy: St.PolicyType.NEVER });
                menu._boxPointer.bin.set_child(null);
                scroll.set_child(menu.box);
                menu._boxPointer.bin.set_child(scroll);
                screen.notificationScroll = scroll;
            }
            this._populateNotificationMenu(menu);
            menu.connect('open-state-changed', (menu, open) => {
                if (!open)
                    return;
                this._populateNotificationMenu(menu);
                if (screen.notificationScroll) {
                    const area = Main.layoutManager.getWorkAreaForMonitor(screen.monitor.index);
                    const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
                    screen.notificationScroll.set_style(`max-height: ${Math.max(1, Math.floor(area.height / scale) - 40)}px;`);
                }
                alignMenuRows(menu.box, Clutter);
            });
            Main.panel.menuManager.addMenu(menu);
            screen.panel.add_child(button.container);
        }
        _updatePanelCalendarEvents(screen, selectedDate = new Date()) {
            if (!screen.calendarEventSource || !screen.calendarEventList)
                return;
            const start = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate());
            const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 1);
            screen.calendarSelectedDate = start;
            screen.calendarEventHeading.text = selectedDate.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
            screen.calendarEventList.destroy_all_children();
            const events = screen.calendarEventSource.getEvents(start, end);
            if (!events.length) {
                screen.calendarEventList.add_child(new St.Label({ text: 'Aucun événement',
                    style_class: 'g-os-calendar-empty' }));
                return;
            }
            for (const event of events) {
                const row = new St.BoxLayout({ style_class: 'g-os-calendar-event',
                    orientation: Clutter.Orientation.VERTICAL, x_expand: true });
                const summary = new St.Label({ text: event.summary || 'Événement',
                    style_class: 'g-os-calendar-event-title', x_expand: true });
                summary.clutter_text.line_wrap = true;
                summary.clutter_text.line_wrap_mode = Pango.WrapMode.WORD_CHAR;
                const allDay = event.date.getHours() === 0 && event.date.getMinutes() === 0 &&
                    event.end.getHours() === 0 && event.end.getMinutes() === 0;
                const time = allDay ? 'Toute la journée' : [event.date, event.end]
                    .map(date => date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }))
                    .join(' - ');
                row.add_child(summary);
                row.add_child(new St.Label({ text: time, style_class: 'g-os-calendar-event-time' }));
                screen.calendarEventList.add_child(row);
            }
        }
        _restorePanelCalendar() {
            const calendar = this._panelCalendarWidget;
            const parent = this._panelCalendarOriginalParent;
            if (calendar && parent) {
                calendar.get_parent()?.remove_child(calendar);
                parent.insert_child_at_index(calendar, this._panelCalendarOriginalIndex);
            }
            if (this._panelCalendarCalendarSignal)
                calendar?.disconnect(this._panelCalendarCalendarSignal);
            if (this._panelCalendarSourceSignal)
                this._panelCalendarEventSource?.disconnect(this._panelCalendarSourceSignal);
            this._panelCalendarWidget = null;
            this._panelCalendarOriginalParent = null;
            this._panelCalendarOriginalIndex = -1;
            this._panelCalendarCalendarSignal = 0;
            this._panelCalendarSourceSignal = 0;
            this._panelCalendarEventSource = null;
        }
        _attachPanelCalendar(screen) {
            const calendar = screen.calendar;
            if (!calendar)
                return;
            const parent = calendar.get_parent();
            if (!this._panelCalendarWidget) {
                this._panelCalendarWidget = calendar;
                this._panelCalendarOriginalParent = parent;
                this._panelCalendarOriginalIndex = parent.get_children().indexOf(calendar);
                this._panelCalendarEventSource = screen.calendarEventSource;
                this._panelCalendarCalendarSignal = calendar.connect('selected-date-changed', (actor, dateTime) => {
                    const selectedDate = new Date(dateTime.to_unix() * 1000);
                    this._panelCalendarSelectedDate = selectedDate;
                    for (const candidate of this._screens)
                        this._updatePanelCalendarEvents(candidate, selectedDate);
                });
                this._panelCalendarSourceSignal = screen.calendarEventSource.connect('changed', () => {
                    for (const candidate of this._screens)
                        this._updatePanelCalendarEvents(candidate, this._panelCalendarSelectedDate);
                });
                this._panelCalendarSelectedDate = new Date(calendar._selectedDate ?? Date.now());
            }
            if (parent !== screen.calendarContent) {
                parent?.remove_child(calendar);
                screen.calendarContent.insert_child_at_index(calendar, 0);
            }
            this._updatePanelCalendarEvents(screen, this._panelCalendarSelectedDate);
        }
        _createPanelCalendar(screen) {
            const dateMenu = Main.panel.statusArea.dateMenu;
            if (!dateMenu?._calendar || !dateMenu?._eventSource)
                return;
            const menu = new PopupMenu.PopupMenu(screen.clockButton, 0.5, St.Side.TOP);
            menu.actor.add_style_class_name('g-os-popup');
            menu.actor.add_style_class_name('g-os-calendar-menu');
            Main.uiGroup.add_child(menu.actor);
            menu.actor.hide();
            screen.calendarMenu = menu;
            const content = new St.BoxLayout({ orientation: Clutter.Orientation.VERTICAL,
                style_class: 'g-os-calendar-content' });
            screen.calendar = dateMenu._calendar;
            screen.calendarEventSource = dateMenu._eventSource;
            screen.calendarContent = content;
            screen.calendarEventHeading = new St.Label({ style_class: 'g-os-calendar-events-heading' });
            content.add_child(screen.calendarEventHeading);
            screen.calendarEventList = new St.BoxLayout({ orientation: Clutter.Orientation.VERTICAL,
                style_class: 'g-os-calendar-events' });
            const scroll = new St.ScrollView({
                hscrollbar_policy: St.PolicyType.NEVER,
                vscrollbar_policy: St.PolicyType.AUTOMATIC,
                style_class: 'g-os-calendar-scroll',
            });
            scroll.set_child(screen.calendarEventList);
            content.add_child(scroll);
            menu.box.add_child(content);
            menu.connect('open-state-changed', (menu, open) => {
                if (open)
                    this._updatePanelCalendarEvents(screen, this._panelCalendarSelectedDate);
            });
            Main.panel.menuManager.addMenu(menu);
            this._updatePanelCalendarEvents(screen, this._panelCalendarSelectedDate ?? new Date());
        }
        _populatePanelMenu(button) {
            button.menu.actor.add_style_class_name('g-os-popup');
            button.menu.addAction('Vue d’ensemble', () => Main.overview.show());
            button.menu.addAction('Applications', () => Main.overview.showApps());
            button.menu.addAction('Rechercher', () => Main.overview.focusSearch());
            const desktop = button.menu.addAction('Afficher le bureau', () => this._toggleDesktop());
            button.menu.addAction('Préférences', () => this.openPreferences());
            const settings = button.menu.addAction('Paramètres système', () => {
                const app = this._appSystem.lookup_app('org.gnome.Settings.desktop');
                if (app) {
                    Main.overview.hide();
                    app.activate();
                }
            });
            const actions = SystemActions.getDefault();
            const lock = button.menu.addAction('Verrouiller la session', () => {
                if (actions.canLockScreen)
                    actions.activateLockScreen();
            });
            const updateLock = () => lock.setSensitive(actions.canLockScreen);
            updateLock();
            const lockSignal = actions.connect('notify::can-lock-screen', updateLock);
            button.connect('destroy', () => actions.disconnect(lockSignal));
            settings.setSensitive(Boolean(this._appSystem.lookup_app('org.gnome.Settings.desktop')));
            button.menu.connect('open-state-changed', (menu, open) => {
                if (open) {
                    desktop.label.text = this._desktopActionName();
                    settings.setSensitive(Boolean(this._appSystem.lookup_app('org.gnome.Settings.desktop')));
                    updateLock();
                    alignMenuRows(button.menu.box, Clutter);
                }
            });
        }
        _populateAppMenu(button) {
            button.menu.actor.add_style_class_name('g-os-popup');
            const quit = button.menu.addAction('Quitter l’application', () => {
                quit.targetApp?.request_quit();
            });
            const updateQuit = () => {
                const window = global.display.focus_window;
                const app = window ? Shell.WindowTracker.get_default().get_window_app(window) : null;
                quit.targetApp = typeof app?.request_quit === 'function' ? app : null;
                quit.label.text = quit.targetApp ? `Quitter ${quit.targetApp.get_name()}` : 'Quitter l’application';
                quit.setSensitive(Boolean(quit.targetApp));
            };
            updateQuit();
            button.menu.connect('open-state-changed', (menu, open) => {
                if (open) {
                    updateQuit();
                    alignMenuRows(button.menu.box, Clutter);
                }
            });
        }
        _syncPanelGlobalMenu(screen) {
            if (screen.globalMenu && this._settings.get_boolean('global-menu-enabled'))
                return;
            if (!this._settings.get_boolean('global-menu-enabled')) {
                screen.globalMenu?.destroy();
                screen.globalMenuBox?.destroy();
                screen.globalMenu = null;
                screen.globalMenuBox = null;
                return;
            }
            screen.globalMenuBox = new St.BoxLayout({ style_class: 'g-os-global-menu' });
            const index = screen.panel.get_children().indexOf(screen.appMenuButton.container) + 1;
            screen.panel.insert_child_at_index(screen.globalMenuBox, index);
            screen.globalMenu = new GtkGlobalMenu(screen.globalMenuBox, {
                Gio, GLib, St, Clutter, PopupMenu,
                menuManager: Main.panel.menuManager, uiGroup: Main.uiGroup,
                registrar: this._menuRegistrar, timestamp: () => global.get_current_time(), stylePrefix: 'g-os',
                textPadding: this._settings.get_int('panel-text-padding'),
                getMenuBounds: () => {
                    const area = Main.layoutManager.getWorkAreaForMonitor(screen.monitor.index);
                    const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
                    return { width: Math.floor(area.width / scale), height: Math.floor(area.height / scale) };
                },
            });
        }
        _createPanel(screen) {
            const { monitor } = screen;
            screen.panel = new St.BoxLayout({
                name: 'panel',
                style_class: 'g-os-secondary-panel',
                height: this._settings.get_int('panel-height'),
                reactive: true,
            });
            if (this._settings.get_boolean('panel-style'))
                screen.panel.add_style_class_name('g-os-panel');
            screen.menuButton = monitor.index === Main.layoutManager.primaryIndex
                ? this._menu : new PanelMenu.Button(0.0, 'Applications');
            screen.menuButton.add_style_class_name('g-os-panel-menu');
            if (screen.menuButton !== this._menu) {
                screen.menuIcon = new St.Icon({
                    icon_name: 'view-app-grid-symbolic',
                    style_class: 'system-status-icon',
                });
                screen.menuButton.add_child(screen.menuIcon);
                this._populatePanelMenu(screen.menuButton);
            }
            else
                screen.menuIcon = this._menuIcon;
            Main.panel.menuManager.addMenu(screen.menuButton.menu);
            screen.panel.add_child(screen.menuButton.container);
            screen.appLabel = monitor.index === Main.layoutManager.primaryIndex
                ? this._activeAppLabel : new St.Label({
                style_class: 'g-os-active-app',
                y_align: Clutter.ActorAlign.CENTER,
                visible: this._settings.get_boolean('show-active-app'),
            });
            screen.appLabel.visible = this._settings.get_boolean('show-active-app');
            screen.appMenuButton = new PanelMenu.Button(0.0, 'Application');
            screen.appMenuButton.add_style_class_name('g-os-app-menu');
            screen.appMenuButton.set_style('padding: 0; margin: 0; min-height: 0;');
            screen.appMenuButton.container.visible = screen.appLabel.visible;
            screen.appMenuButton.add_child(screen.appLabel);
            this._populateAppMenu(screen.appMenuButton);
            Main.panel.menuManager.addMenu(screen.appMenuButton.menu);
            screen.panel.add_child(screen.appMenuButton.container);
            this._syncPanelGlobalMenu(screen);
            screen.transferLabel = monitor.index === Main.layoutManager.primaryIndex
                ? this._transferLabel : new St.Label({
                style_class: 'g-os-transfer-total',
                y_align: Clutter.ActorAlign.CENTER,
                visible: false,
            });
            screen.panel.add_child(screen.transferLabel);
            screen.panel.add_child(new St.Widget({ x_expand: true }));
            screen.clock = new St.Label({ name: 'g-os-panel-clock', y_align: Clutter.ActorAlign.CENTER,
                visible: this._settings.get_boolean('panel-show-clock') });
            screen.clockButton = new St.Button({ accessible_name: 'Calendrier et événements',
                can_focus: true, child: screen.clock, visible: screen.clock.visible });
            screen.clockButton.set_style('padding: 0; margin: 0; min-height: 0;');
            screen.clockButton.connect('clicked', () => {
                if (!screen.calendarMenu)
                    this._createPanelCalendar(screen);
                if (!screen.calendarMenu)
                    return;
                for (const candidate of this._screens) {
                    if (candidate !== screen && candidate.calendarMenu?.isOpen)
                        candidate.calendarMenu.close();
                }
                this._attachPanelCalendar(screen);
                screen.calendarMenu.toggle();
            });
            screen.panel.add_child(screen.clockButton);
            screen.searchIcon = new St.Icon({ icon_name: 'system-search-symbolic', style_class: 'system-status-icon' });
            const search = new St.Button({
                style_class: 'panel-button',
                accessible_name: 'Rechercher',
                visible: this._settings.get_boolean('panel-show-search'),
                can_focus: true,
                child: screen.searchIcon,
            });
            screen.searchButton = search;
            search.connect('clicked', () => Main.overview.focusSearch());
            screen.panel.add_child(search);
            const preferences = new St.Button({
                style_class: 'panel-button',
                accessible_name: 'Préférences G-Os',
                visible: this._settings.get_boolean('panel-show-preferences'),
                can_focus: true,
                child: screen.preferencesIcon = new St.Icon({
                    icon_name: 'preferences-system-symbolic', style_class: 'system-status-icon',
                }),
            });
            screen.preferencesButton = preferences;
            preferences.connect('clicked', () => this.openPreferences());
            screen.panel.add_child(preferences);
            this._createNotificationButton(screen);
            screen.statusButtons = [];
            for (const [name, iconName, accessibleName] of [
                ['wifi', 'network-wireless-signal-excellent-symbolic', 'Réseau Wi-Fi'],
                ['bluetooth', 'bluetooth-active-symbolic', 'Bluetooth'],
                ['sound', 'audio-volume-high-symbolic', 'Son'],
                ['battery', 'battery-good-symbolic', 'Batterie'],
            ]) {
                const statusIcon = new St.Icon({ icon_name: iconName, style_class: 'system-status-icon' });
                const button = new St.Button({
                    style_class: 'panel-button g-os-status-button',
                    accessible_name: accessibleName,
                    visible: this._settings.get_boolean(`panel-show-${name}`),
                    can_focus: true,
                    child: statusIcon,
                });
                button.statusKind = name;
                button.statusIcon = statusIcon;
                this._createStatusMenu(button);
                button.connect('clicked', () => {
                    if (!button.statusMenu.isOpen)
                        Main.panel.statusArea?.quickSettings?.menu?.close();
                    button.statusMenu.toggle();
                });
                screen.statusButtons.push(button);
                screen.panel.add_child(button);
            }
            screen.sessionButton = new PanelMenu.Button(0.0, 'Session');
            screen.sessionButton.add_style_class_name('g-os-session-button');
            screen.sessionIcon = new St.Icon({
                icon_name: 'avatar-default-symbolic',
                style_class: 'system-status-icon',
            });
            screen.sessionButton.add_child(screen.sessionIcon);
            this._populateSessionMenu(screen.sessionButton);
            Main.panel.menuManager.addMenu(screen.sessionButton.menu);
            screen.panel.add_child(screen.sessionButton.container);
            this._applyPanelMetrics(screen);
            screen.panel.set_position(monitor.x, monitor.y);
            screen.panel.set_width(monitor.width);
            Main.layoutManager.addChrome(screen.panel, { affectsStruts: true, trackFullscreen: true });
        }
        _applyPanelMetrics(screen) {
            const height = this._settings.get_int('panel-height');
            const horizontalPadding = this._settings.get_int('panel-padding-horizontal');
            const iconPadding = this._settings.get_int('panel-icon-padding');
            const textPadding = this._settings.get_int('panel-text-padding');
            const verticalPadding = Math.min(this._settings.get_int('panel-padding-vertical'), Math.max(0, Math.floor((height - 22) / 2)));
            const contentHeight = height - verticalPadding * 2;
            const availableLabelWidth = Math.max(48, screen.monitor.width - 360 - horizontalPadding * 2);
            const baseFontSize = Math.max(10, Math.min(20, Math.floor(contentHeight * 0.56)));
            const labelLength = screen.appLabel.text?.length ?? 0;
            const estimatedLabelWidth = labelLength * baseFontSize * 0.56;
            const widthScale = estimatedLabelWidth > 0
                ? Math.min(1, availableLabelWidth / estimatedLabelWidth) : 1;
            screen.fontSize = Math.max(10, Math.floor(baseFontSize * widthScale));
            screen.iconSize = Math.max(16, screen.fontSize);
            screen.panel.set_style(`padding: ${verticalPadding}px ${horizontalPadding}px;`);
            screen.appLabel.clutter_text.ellipsize = Pango.EllipsizeMode.END;
            screen.appLabel.y_align = Clutter.ActorAlign.CENTER;
            screen.appLabel.set_style(`font-size: ${screen.fontSize}px; max-width: ${availableLabelWidth}px; padding: 0 ${textPadding}px;`);
            for (const label of [screen.clock, screen.transferLabel]) {
                label.y_align = Clutter.ActorAlign.CENTER;
                label.set_style(`font-size: ${screen.fontSize}px; padding: 0 ${textPadding}px;`);
            }
            for (const button of [screen.menuButton.container, screen.searchButton, screen.preferencesButton,
                screen.notificationButton.container,
                ...screen.statusButtons, screen.sessionButton.container]) {
                button.y_align = Clutter.ActorAlign.CENTER;
                button.set_style(`padding: 0 ${iconPadding}px;`);
            }
            screen.appMenuButton.container.y_align = Clutter.ActorAlign.CENTER;
            if (screen.globalMenuBox) {
                screen.globalMenuBox.y_align = Clutter.ActorAlign.CENTER;
                screen.globalMenuBox.set_style(`font-size: ${screen.fontSize}px;`);
            }
            for (const button of screen.globalMenuBox?.get_children() ?? [])
                button.set_style(`padding: 0 ${textPadding}px; margin: 0; min-height: 0;`);
            for (const icon of [screen.menuIcon, screen.searchIcon, screen.preferencesIcon, screen.notificationIcon,
                ...screen.statusButtons.map(button => button.statusIcon), screen.sessionIcon]) {
                if (!icon)
                    continue;
                icon.y_align = Clutter.ActorAlign.CENTER;
                icon.set_style(`icon-size: ${screen.iconSize}px;`);
            }
        }
        _createStatusMenu(button) {
            const menu = new PopupMenu.PopupMenu(button, 0.5, St.Side.TOP);
            menu.actor.add_style_class_name('g-os-popup');
            menu.actor.add_style_class_name(`g-os-status-menu-${button.statusKind}`);
            Main.uiGroup.add_child(menu.actor);
            menu.actor.hide();
            Main.panel.menuManager.addMenu(menu);
            button.statusMenu = menu;
            const quick = Main.panel.statusArea?.quickSettings;
            const settings = panel => () => {
                const app = this._appSystem.lookup_app(`gnome-${panel}-panel.desktop`) ??
                    this._appSystem.lookup_app('org.gnome.Settings.desktop');
                app?.activate();
            };
            if (button.statusKind === 'sound') {
                button.statusController = new SoundStatusMenu(menu, button.statusIcon, {
                    control: Volume.getMixerControl(), St, Slider, PopupMenu, Clutter, openSettings: settings('sound'),
                });
                button.connect('scroll-event', (actor, event) => button.statusController.adjustVolume(event.get_scroll_direction()));
            }
            else if (['wifi', 'bluetooth'].includes(button.statusKind)) {
                const toggle = button.statusKind === 'wifi' ? quick?._network?._wirelessToggle
                    : quick?._bluetooth?.quickSettingsItems?.[0];
                button.statusController = new RadioStatusMenu(menu, button.statusIcon, { toggle,
                    title: button.statusKind === 'wifi' ? 'Wi-Fi' : 'Bluetooth', St, Clutter, PopupMenu,
                    deviceChangeSignal: button.statusKind === 'bluetooth' ? 'devices-changed' : null,
                    openSettings: settings(button.statusKind === 'wifi' ? 'wifi' : 'bluetooth') });
            }
            else {
                button.statusController = new BatteryStatusMenu(menu, button.statusIcon, {
                    powerToggle: quick?._system?._systemItem?.powerToggle ?? quick?._system?._systemItem?._powerToggle ??
                        quick?._system?.quickSettingsItems?.[0]?.powerToggle,
                    deviceClient: createPowerDeviceClient(Gio), batteryKind: 2,
                    profiles: quick?._powerProfiles?._powerProfilesToggle, St, Clutter, PopupMenu, openSettings: settings('power'),
                });
            }
            menu.connect('open-state-changed', (actor, open) => {
                if (open)
                    alignMenuRows(menu.box, Clutter);
            });
            button.connect('popup-menu', () => {
                Main.panel.statusArea?.quickSettings?.menu?.close();
                menu.open();
            });
        }
        _openQuickSettings(button) {
            const menu = Main.panel.statusArea?.quickSettings?.menu;
            if (!menu)
                return;
            if (menu.isOpen) {
                menu.close();
                return;
            }
            Reflect.set(menu, 'sourceActor', button);
            menu.open();
        }
        _populateSessionMenu(button) {
            const actions = SystemActions.getDefault();
            button.menu.actor.add_style_class_name('g-os-popup');
            const addSystemAction = (label, available, activate) => {
                const item = button.menu.addAction(label, () => {
                    if (actions[available])
                        actions[activate]();
                });
                item.setSensitive(Boolean(actions[available]));
                return item;
            };
            const restart = addSystemAction('Redémarrer', 'canRestart', 'activateRestart');
            const powerOff = addSystemAction('Éteindre', 'canPowerOff', 'activatePowerOff');
            const logout = addSystemAction('Se déconnecter', 'canLogout', 'activateLogout');
            button.menu.addAction('Préférences G-Os', () => this.openPreferences());
            const settings = button.menu.addAction('Paramètres système', () => {
                const app = this._appSystem.lookup_app('org.gnome.Settings.desktop');
                if (app) {
                    Main.overview.hide();
                    app.activate();
                }
            });
            const lock = addSystemAction('Verrouiller la session', 'canLockScreen', 'activateLockScreen');
            const suspend = addSystemAction('Suspendre', 'canSuspend', 'activateSuspend');
            const updateSensitivity = () => {
                for (const [item, capability] of [[restart, 'canRestart'], [powerOff, 'canPowerOff'],
                    [logout, 'canLogout'], [lock, 'canLockScreen'], [suspend, 'canSuspend']])
                    item.setSensitive(Boolean(actions[capability]));
                settings.setSensitive(Boolean(this._appSystem.lookup_app('org.gnome.Settings.desktop')));
            };
            updateSensitivity();
            button.menu.connect('open-state-changed', (menu, open) => {
                if (open) {
                    updateSensitivity();
                    alignMenuRows(button.menu.box, Clutter);
                }
            });
        }
        _updateClocks() {
            const text = this._wallClock.clock;
            for (const screen of this._screens) {
                if (screen.clock)
                    screen.clock.text = text;
            }
        }
    };
}
//# sourceMappingURL=panel.js.map