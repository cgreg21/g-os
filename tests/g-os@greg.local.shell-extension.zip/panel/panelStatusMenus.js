export function alignMenuRows(actor, Clutter) {
    if (!actor)
        return;
    if (['popup-menu-item', 'bt-device-item', 'nm-network-item'].some(name => actor.has_style_class_name?.(name))) {
        for (const child of actor.get_children())
            child.y_align = Clutter.ActorAlign.CENTER;
    }
    for (const child of actor.get_children?.() ?? [])
        alignMenuRows(child, Clutter);
}
export class SoundStatusMenu {
    constructor(menu, icon, { control, St, Slider, PopupMenu, Clutter, openSettings }) {
        this.menu = menu;
        this.icon = icon;
        this.control = control;
        this.Clutter = Clutter;
        this.PopupMenu = PopupMenu;
        this.streamSignals = [];
        this.controlSignals = [];
        const row = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
        this.muteIcon = new St.Icon({ icon_name: 'audio-volume-high-symbolic', icon_size: 20 });
        this.muteButton = new St.Button({ child: this.muteIcon, can_focus: true, reactive: true, track_hover: true,
            style_class: 'g-os-sound-mute', accessible_name: 'Couper le son' });
        this.muteButton.connect('clicked', () => this.toggleMute());
        this.slider = new Slider.Slider(0);
        this.muteButton.y_align = Clutter.ActorAlign.CENTER;
        this.slider.y_align = Clutter.ActorAlign.CENTER;
        this.slider.width = 200;
        this.slider.accessible_name = 'Volume de sortie';
        this.sliderSignal = this.slider.connect('notify::value', () => this.changeVolume());
        row.add_child(this.muteButton);
        row.add_child(this.slider);
        menu.addMenuItem(row);
        this.percentage = new PopupMenu.PopupMenuItem('Volume indisponible', { reactive: false, can_focus: false });
        this.percentage.add_style_class_name('g-os-status-info');
        menu.addMenuItem(this.percentage);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Sortie audio'));
        this.devices = new PopupMenu.PopupMenuSection();
        menu.addMenuItem(this.devices);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        menu.addAction('Parametres du son', openSettings);
        this.openSignal = menu.connect('open-state-changed', (actor, open) => {
            if (open)
                this.syncOutput();
        });
        for (const signal of ['state-changed', 'default-sink-changed', 'stream-added', 'stream-removed', 'output-added', 'output-removed'])
            this.controlSignals.push(control.connect(signal, () => this.syncOutput()));
        this.syncOutput();
    }
    syncOutput() {
        const stream = this.control.get_default_sink();
        if (stream !== this.stream) {
            for (const id of this.streamSignals)
                this.stream?.disconnect(id);
            this.streamSignals = [];
            this.stream = stream;
            if (stream) {
                for (const signal of ['notify::volume', 'notify::is-muted'])
                    this.streamSignals.push(stream.connect(signal, () => this.refresh()));
            }
        }
        this.refresh();
        this.refreshDevices();
    }
    refresh() {
        const maximum = this.control.get_vol_max_norm() || 1;
        const level = this.stream ? Math.max(0, this.stream.volume / maximum) : 0;
        const volume = Math.min(1, level);
        const muted = !this.stream || this.stream.is_muted || volume === 0;
        this.syncing = true;
        this.slider.value = volume;
        this.syncing = false;
        this.slider.reactive = Boolean(this.stream);
        this.slider.can_focus = Boolean(this.stream);
        this.muteButton.reactive = Boolean(this.stream);
        this.muteButton.can_focus = Boolean(this.stream);
        if (this.stream)
            this.muteButton.remove_style_pseudo_class('insensitive');
        else
            this.muteButton.add_style_pseudo_class('insensitive');
        const icon = muted ? 'audio-volume-muted-symbolic' : volume < 0.34 ? 'audio-volume-low-symbolic'
            : volume < 0.67 ? 'audio-volume-medium-symbolic' : 'audio-volume-high-symbolic';
        this.icon.icon_name = icon;
        this.muteIcon.icon_name = icon;
        this.muteButton.accessible_name = muted ? 'Activer le son' : 'Couper le son';
        this.percentage.label.text = this.stream ? `${Math.round(level * 100)} %${muted ? ' - Muet' : ''}` : 'Aucune sortie audio';
    }
    changeVolume() {
        if (this.syncing || !this.stream)
            return;
        const volume = Math.round(Math.max(0, Math.min(1, this.slider.value)) * this.control.get_vol_max_norm());
        this.stream.set_volume(volume);
        this.stream.push_volume();
        this.stream.change_is_muted(volume === 0);
        this.refresh();
    }
    adjustVolume(direction) {
        if (!this.stream)
            return this.Clutter.EVENT_STOP;
        const change = direction === this.Clutter.ScrollDirection.UP ? 0.05
            : direction === this.Clutter.ScrollDirection.DOWN ? -0.05 : 0;
        if (change === 0)
            return this.Clutter.EVENT_STOP;
        const maximum = this.control.get_vol_max_norm() || 1;
        const current = Math.max(0, Math.min(1, this.stream.volume / maximum));
        this.syncing = true;
        this.slider.value = Math.max(0, Math.min(1, current + change));
        this.syncing = false;
        this.changeVolume();
        return this.Clutter.EVENT_STOP;
    }
    toggleMute() {
        if (!this.stream)
            return;
        const muted = this.stream.is_muted || this.stream.volume === 0;
        if (muted && this.stream.volume === 0) {
            this.stream.set_volume(Math.round(this.control.get_vol_max_norm() * 0.25));
            this.stream.push_volume();
        }
        this.stream.change_is_muted(!muted);
        this.refresh();
    }
    refreshDevices() {
        this.devices.removeAll();
        const streams = this.control.get_sinks();
        let count = 0;
        for (const stream of streams) {
            const device = this.control.lookup_device_from_stream(stream);
            if (!device)
                continue;
            const label = stream.get_description() || stream.get_name() || 'Sortie audio';
            const item = this.devices.addAction(label, () => this.control.change_output(device.get_id()));
            count++;
            item.setOrnament(stream === this.stream ? this.PopupMenu.Ornament.DOT : this.PopupMenu.Ornament.NONE);
        }
        if (count === 0) {
            const item = this.devices.addAction('Aucune sortie audio disponible', () => { });
            item.setSensitive(false);
        }
        alignMenuRows(this.devices.actor, this.Clutter);
    }
    destroy() {
        this.menu.disconnect(this.openSignal);
        this.slider.disconnect(this.sliderSignal);
        for (const id of this.streamSignals)
            this.stream?.disconnect(id);
        for (const id of this.controlSignals)
            this.control.disconnect(id);
        this.streamSignals = [];
        this.controlSignals = [];
    }
}
class NativeMenuContent {
    constructor(menu, holder, { Clutter, onOpen = () => { }, onClose = () => { } } = {}) {
        this.menu = menu;
        this.holder = holder;
        this.Clutter = Clutter;
        this.onOpen = onOpen;
        this.onClose = onClose;
    }
    alignDeviceRows(actor = this.saved?.actor) {
        alignMenuRows(actor, this.Clutter);
    }
    mount(nativeMenu, notifyOpen = true) {
        this.restore();
        const actor = nativeMenu?.box;
        const parent = actor?.get_parent();
        if (!parent)
            return false;
        const index = parent.get_children().indexOf(actor);
        this.saved = { actor, parent, index, nativeMenu, notifyOpen, wasOpen: Boolean(nativeMenu.isOpen) };
        parent.remove_child(actor);
        actor.add_style_class_name('g-os-status-native-content');
        this.holder.add_child(actor);
        actor.show();
        this.alignDeviceRows(actor);
        this.activateSignal = nativeMenu.connect('activate', () => this.menu.close());
        nativeMenu.isOpen = true;
        if (notifyOpen)
            this.onOpen();
        return true;
    }
    restore() {
        if (!this.saved)
            return;
        const { actor, parent, index, nativeMenu, notifyOpen, wasOpen } = this.saved;
        nativeMenu.disconnect(this.activateSignal);
        actor.get_parent()?.remove_child(actor);
        actor.remove_style_class_name('g-os-status-native-content');
        parent.insert_child_at_index(actor, index);
        this.saved = null;
        nativeMenu.isOpen = wasOpen;
        if (notifyOpen)
            this.onClose();
    }
}
export class RadioStatusMenu {
    constructor(menu, icon, { toggle, title, St, Clutter, PopupMenu, openSettings, deviceChangeSignal = null }) {
        this.menu = menu;
        this.icon = icon;
        this.toggle = toggle;
        this.header = new PopupMenu.PopupSwitchMenuItem(title, Boolean(toggle?.checked));
        this.header.setSensitive(Boolean(toggle) && toggle.visible !== false && toggle.reactive !== false);
        this.header.connect('toggled', (actor, checked) => {
            if (toggle && checked !== Boolean(toggle.checked))
                toggle.emit('clicked', 1);
        });
        menu.addMenuItem(this.header);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const item = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
        this.holder = new St.BoxLayout({ orientation: Clutter.Orientation.VERTICAL });
        item.add_child(this.holder);
        menu.addMenuItem(item);
        this.content = new NativeMenuContent(menu, this.holder, { Clutter,
            onOpen: () => {
                toggle?._startScanning?.();
                toggle?._reorderDeviceItems?.();
            },
            onClose: () => toggle?._stopScanning?.(),
        });
        if (!toggle) {
            const unavailable = new PopupMenu.PopupMenuItem('Service indisponible', { reactive: false, can_focus: false });
            menu.addMenuItem(unavailable);
        }
        this.settingsSeparator = new PopupMenu.PopupSeparatorMenuItem();
        menu.addMenuItem(this.settingsSeparator);
        this.settingsItem = menu.addAction(`Parametres ${title}`, openSettings);
        this.deviceSignal = deviceChangeSignal
            ? toggle?._client?.connect(deviceChangeSignal, () => this.content.alignDeviceRows()) ?? 0 : 0;
        this.signals = [];
        if (toggle) {
            for (const signal of ['notify::checked', 'notify::icon-name', 'notify::visible', 'notify::reactive'])
                this.signals.push(toggle.connect(signal, () => this.refresh()));
        }
        this.openSignal = menu.connect('open-state-changed', (actor, open) => {
            if (open) {
                const mounted = this.content.mount(toggle?.menu, Boolean(toggle) && toggle.visible !== false);
                this.settingsItem.visible = !mounted;
                this.settingsSeparator.visible = !mounted;
                this.refresh();
            }
            else
                this.content.restore();
        });
        this.refresh();
    }
    refresh() {
        this.header.setToggleState(Boolean(this.toggle?.checked));
        this.header.setSensitive(Boolean(this.toggle) && this.toggle.visible !== false && this.toggle.reactive !== false);
        if (this.toggle?.icon_name)
            this.icon.icon_name = this.toggle.icon_name;
    }
    destroy() {
        this.content.restore();
        if (this.deviceSignal)
            this.toggle._client.disconnect(this.deviceSignal);
        this.deviceSignal = 0;
        this.menu.disconnect(this.openSignal);
        for (const id of this.signals)
            this.toggle.disconnect(id);
    }
}
export class BatteryStatusMenu {
    constructor(menu, icon, { powerToggle, profiles, deviceClient, batteryKind, St, Clutter, PopupMenu, openSettings }) {
        this.menu = menu;
        this.icon = icon;
        this.powerToggle = powerToggle;
        this.Clutter = Clutter;
        this.proxy = powerToggle?._proxy;
        this.profiles = profiles;
        this.PopupMenu = PopupMenu;
        this.deviceClient = deviceClient;
        this.batteryKind = batteryKind;
        this.devices = [];
        this.deviceConnections = new Map();
        this.deviceSignals = [];
        this.deviceClientSignals = [];
        this.percentage = new PopupMenu.PopupMenuItem('', { reactive: false, can_focus: false });
        this.state = new PopupMenu.PopupMenuItem('', { reactive: false, can_focus: false });
        this.percentage.add_style_class_name('g-os-status-info');
        this.state.add_style_class_name('g-os-status-info');
        menu.addMenuItem(this.percentage);
        menu.addMenuItem(this.state);
        this.deviceHeading = new PopupMenu.PopupMenuItem('Batteries détectées', { reactive: false, can_focus: false });
        this.deviceHeading.visible = false;
        this.deviceItems = new PopupMenu.PopupMenuSection();
        menu.addMenuItem(this.deviceHeading);
        menu.addMenuItem(this.deviceItems);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Mode d\u2019alimentation'));
        const item = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false });
        this.holder = new St.BoxLayout({ orientation: Clutter.Orientation.VERTICAL });
        item.add_child(this.holder);
        menu.addMenuItem(item);
        this.content = new NativeMenuContent(menu, this.holder, { Clutter });
        if (!profiles) {
            const unavailable = new PopupMenu.PopupMenuItem('Profils indisponibles', { reactive: false, can_focus: false });
            menu.addMenuItem(unavailable);
        }
        this.settingsSeparator = new PopupMenu.PopupSeparatorMenuItem();
        menu.addMenuItem(this.settingsSeparator);
        this.settingsItem = menu.addAction('Parametres d\u2019alimentation', openSettings);
        this.proxySignal = this.proxy?.connect('g-properties-changed', () => this.refresh());
        if (deviceClient) {
            try {
                this.devices = deviceClient.get_devices2() ?? [];
            }
            catch {
                this.devices = [];
            }
            this.deviceClientSignals.push(deviceClient.connect('device-added', (client, device) => {
                if (!this.devices.includes(device))
                    this.devices.push(device);
                this.refresh();
            }));
            this.deviceClientSignals.push(deviceClient.connect('device-removed', (client, objectPath) => {
                this.devices = this.devices.filter(device => device.get_object_path() !== objectPath);
                this.refresh();
            }));
        }
        this.openSignal = menu.connect('open-state-changed', (actor, open) => {
            if (open) {
                const mounted = this.content.mount(profiles?.menu);
                this.settingsItem.visible = !mounted;
                this.settingsSeparator.visible = !mounted;
                this.refresh();
            }
            else
                this.content.restore();
        });
        this.refresh();
    }
    refresh() {
        const batteries = this.syncDevices();
        const proxy = this.proxy;
        this.percentage.visible = batteries.length === 0;
        this.state.visible = batteries.length === 0;
        this.deviceHeading.visible = batteries.length > 0;
        if (batteries.length) {
            const primary = batteries.find(device => device.power_supply) ?? batteries[0];
            this.icon.icon_name = proxy?.IconName || primary.icon_name || 'battery-good-symbolic';
        }
        if (!proxy?.IsPresent) {
            this.percentage.label.text = batteries.length ? '' : 'Aucune batterie';
            this.state.label.text = batteries.length ? '' : 'Alimentation secteur';
            if (!batteries.length)
                this.icon.icon_name = 'battery-missing-symbolic';
            return;
        }
        this.percentage.label.text = `Batterie : ${Math.round(proxy.Percentage)} %`;
        const states = ['Etat inconnu', 'En charge', 'Sur batterie', 'Batterie vide', 'Charge complete', 'Charge en attente', 'Decharge en attente'];
        const seconds = proxy.State === 1 ? proxy.TimeToFull : proxy.State === 2 ? proxy.TimeToEmpty : 0;
        const minutes = Math.max(0, Math.round(Number(seconds) / 60));
        const time = minutes > 0 ? ` - ${Math.floor(minutes / 60)} h ${minutes % 60} min` : '';
        this.state.label.text = `${states[proxy.State] ?? states[0]}${time}`;
        const percentage = Number(proxy.Percentage);
        const level = proxy.State === 3 ? 'empty' : percentage >= 95 ? 'full' : percentage >= 60 ? 'good'
            : percentage >= 20 ? 'caution' : percentage > 0 ? 'low' : 'empty';
        const fallbackIcon = proxy.State === 4 ? 'battery-full-charged-symbolic'
            : `battery-${level}${proxy.State === 1 ? '-charging' : ''}-symbolic`;
        this.icon.icon_name = proxy.IconName || fallbackIcon;
    }
    syncDevices() {
        const batteryDevices = this.devices.filter(device => (device.kind === this.batteryKind || device.is_rechargeable));
        const batteries = batteryDevices.filter(device => device.is_present);
        const currentDevices = new Set(batteryDevices);
        for (const [device, signals] of this.deviceConnections) {
            if (currentDevices.has(device))
                continue;
            for (const id of signals)
                device.disconnect(id);
            this.deviceConnections.delete(device);
        }
        for (const device of batteries) {
            if (this.deviceConnections.has(device))
                continue;
            const signals = ['notify::percentage', 'notify::state', 'notify::is-present', 'notify::kind',
                'notify::model', 'notify::vendor', 'notify::native-path', 'notify::power-supply',
                'notify::icon-name', 'notify::time-to-empty', 'notify::time-to-full']
                .map(signal => device.connect(signal, () => this.refresh()));
            this.deviceConnections.set(device, signals);
        }
        this.deviceItems.removeAll();
        const states = ['Etat inconnu', 'En charge', 'Sur batterie', 'Batterie vide', 'Charge complete',
            'Charge en attente', 'Decharge en attente'];
        batteries.forEach((device, index) => {
            const percentage = Number(device.percentage);
            const charge = Number.isFinite(percentage) ? `${Math.round(percentage)} %` : 'inconnue';
            const seconds = device.state === 1 ? device.time_to_full : device.state === 2 ? device.time_to_empty : 0;
            const minutes = Math.max(0, Math.round(Number(seconds) / 60));
            const time = minutes > 0 ? ` - ${Math.floor(minutes / 60)} h ${minutes % 60} min` : '';
            const model = [device.vendor, device.model].filter(Boolean).join(' ') || `Batterie ${index + 1}`;
            const category = /\/org\/bluez\//i.test(device.native_path ?? '') ? 'Bluetooth'
                : device.power_supply ? 'Interne' : 'Périphérique';
            this.deviceItems.addMenuItem(new this.PopupMenu.PopupMenuItem(`${category} : ${model} - ${charge} - ${states[device.state] ?? states[0]}${time}`, {
                reactive: false, can_focus: false,
            }));
        });
        alignMenuRows(this.deviceItems.actor, this.Clutter);
        return batteries;
    }
    destroy() {
        this.content.restore();
        this.menu.disconnect(this.openSignal);
        if (this.proxySignal)
            this.proxy.disconnect(this.proxySignal);
        for (const id of this.deviceClientSignals)
            this.deviceClient.disconnect(id);
        for (const [device, signals] of this.deviceConnections) {
            for (const id of signals)
                device.disconnect(id);
        }
        this.deviceClientSignals = [];
        this.deviceConnections.clear();
        this.devices = [];
        this.deviceClient?.dispose?.();
    }
}
export function createPowerDeviceClient(Gio) {
    const devices = new Map();
    const handlers = new Map();
    let nextHandler = 0;
    const emit = (signal, ...args) => {
        for (const [name, callback] of handlers.values()) {
            if (name === signal)
                callback(client, ...args);
        }
    };
    const createDevice = objectPath => {
        const proxy = Gio.DBusProxy.new_for_bus_sync(Gio.BusType.SYSTEM, Gio.DBusProxyFlags.NONE, null, 'org.freedesktop.UPower', objectPath, 'org.freedesktop.UPower.Device', null);
        const properties = {
            kind: 'Type', is_present: 'IsPresent', is_rechargeable: 'IsRechargeable', percentage: 'Percentage',
            state: 'State', vendor: 'Vendor', model: 'Model', power_supply: 'PowerSupply', native_path: 'NativePath',
            icon_name: 'IconName', time_to_full: 'TimeToFull', time_to_empty: 'TimeToEmpty',
        };
        const device = {
            get_object_path: () => objectPath,
            connect(signal, callback) {
                const property = properties[signal.slice('notify::'.length).replaceAll('-', '_')];
                return proxy.connect('g-properties-changed', (_proxy, changed, invalidated) => {
                    if (changed.lookup_value(property, null) || invalidated.includes(property))
                        callback(device);
                });
            },
            disconnect: id => proxy.disconnect(id),
        };
        for (const [name, property] of Object.entries(properties)) {
            Object.defineProperty(device, name, { get: () => proxy.get_cached_property(property)?.deep_unpack() });
        }
        return device;
    };
    const client = {
        get_devices2: () => [...devices.values()],
        connect(signal, callback) {
            const id = ++nextHandler;
            handlers.set(id, [signal, callback]);
            return id;
        },
        disconnect: id => handlers.delete(id),
        dispose() {
            if (rootSignal)
                root.disconnect(rootSignal);
            devices.clear();
            handlers.clear();
        },
    };
    let root;
    let rootSignal;
    try {
        root = Gio.DBusProxy.new_for_bus_sync(Gio.BusType.SYSTEM, Gio.DBusProxyFlags.NONE, null, 'org.freedesktop.UPower', '/org/freedesktop/UPower', 'org.freedesktop.UPower', null);
        const add = objectPath => {
            if (devices.has(objectPath))
                return;
            try {
                const device = createDevice(objectPath);
                devices.set(objectPath, device);
                emit('device-added', device);
            }
            catch { }
        };
        rootSignal = root.connect('g-signal', (_proxy, _sender, signal, parameters) => {
            const [objectPath] = parameters.deep_unpack();
            if (signal === 'DeviceAdded')
                add(objectPath);
            else if (signal === 'DeviceRemoved' && devices.delete(objectPath))
                emit('device-removed', objectPath);
        });
        for (const objectPath of root.call_sync('EnumerateDevices', null, Gio.DBusCallFlags.NONE, -1, null)
            .deep_unpack()[0]) {
            try {
                devices.set(objectPath, createDevice(objectPath));
            }
            catch { }
        }
    }
    catch {
        root = null;
    }
    return client;
}
//# sourceMappingURL=panelStatusMenus.js.map